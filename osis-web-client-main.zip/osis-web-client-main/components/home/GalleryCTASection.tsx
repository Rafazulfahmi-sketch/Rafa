"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "motion/react";

export default function GalleryCTASection() {
  const [index, setIndex] = useState(0);
  const images = [
    "/assets/home/gallery/gallery-center.png",
    "/assets/home/gallery/gallery-left.png",
    "/assets/home/gallery/gallery-right.png",
  ];

  useEffect(() => {
    // Using 5 minutes as requested
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % images.length);
    }, 300000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-5 md:py-20 bg-[#003F7D] overflow-hidden md:mb-30">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex flex-col xl:flex-row items-center justify-center gap-5">
          <motion.div
            initial={{ x: -30, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.6,
              delay: 0.2,
              ease: "easeOut",
            }}
            className="md:relative w-72 h-125 shrink-0 hidden md:block rounded-r-[10px] overflow-hidden"
          >
            <Image
              src="/assets/home/gallery/gallery-left.png"
              alt="Gallery Left"
              fill
              className="object-cover"
            />
          </motion.div>
          <div className="flex flex-col gap-3 w-full md:w-60 shrink-0">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 1, ease: "easeOut" }}
              className="md:block hidden relative w-full h-60 rounded-[10px] overflow-hidden"
            >
              <Image
                src="/assets/home/gallery/gallery-left-grid-top.png"
                alt="Gallery Left Top"
                fill
                className="object-cover"
              />
            </motion.div>
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.6, ease: "easeOut" }}
              className="md:block hidden relative w-full h-80 rounded-[10px] overflow-hidden"
            >
              <Image
                src="/assets/home/gallery/gallery-left-grid-bot.png"
                alt="Gallery Left Bottom"
                fill
                className="object-cover"
              />
            </motion.div>
          </div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 1.4, ease: "easeOut" }}
            className="relative w-full md:w-98 h-150 shrink-0 rounded-[10px] overflow-hidden group"
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={images[index]}
                initial={{ x: 300, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -300, opacity: 0 }}
                transition={{ duration: 0.8, ease: "easeInOut" }}
                className="absolute inset-0"
              >
                <Image
                  src={images[index]}
                  alt="Gallery Center"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-black/60" />
                <div className="absolute inset-0 flex items-center justify-center p-8">
                  <h2 className="font-inter font-black text-[70px] leading-tight text-center text-white uppercase drop-shadow-xl">
                    CERMAT <br /> CEPAT <br /> TEPAT
                  </h2>
                </div>
              </motion.div>
            </AnimatePresence>
          </motion.div>

          <div className="hidden md:flex flex-col gap-3 w-full md:w-60 shrink-0">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 1.2, ease: "easeOut" }}
              className="relative w-full h-60 rounded-[10px] overflow-hidden"
            >
              <Image
                src="/assets/home/gallery/gallery-right-grid-top.png"
                alt="Gallery Right Top"
                fill
                className="object-cover"
              />
            </motion.div>
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.8, ease: "easeOut" }}
              className="hidden md:block relative w-full h-80 rounded-[10px] overflow-hidden"
            >
              <Image
                src="/assets/home/gallery/gallery-right-grid-bot.png"
                alt="Gallery Right Bottom"
                fill
                className="object-cover"
              />
            </motion.div>
          </div>
          <motion.div
            initial={{ x: 30, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.6,
              delay: 0.4,
              ease: "easeOut",
            }}
            className="relative w-72 h-125 shrink-0 hidden md:block rounded-l-[10px] overflow-hidden"
          >
            <Image
              src="/assets/home/gallery/gallery-right.png"
              alt="Gallery Right"
              fill
              className="object-cover"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
