import AboutSection from "./AboutSection";
import AchievementSection from "./AchievementSection";
import ProfileCTASection from "./ProfileCTASection";
import ProgramSection from "./ProgramSection";
import VisiMisiSection from "./VisiMisiSection";
import GalleryCTASection from "./GalleryCTASection";

const HomeContent = () => {
  return (
    <>
      <AboutSection />
      <VisiMisiSection />
      <ProgramSection />
      <ProfileCTASection />
      <AchievementSection />
      <GalleryCTASection />
    </>
  );
};

export default HomeContent;
