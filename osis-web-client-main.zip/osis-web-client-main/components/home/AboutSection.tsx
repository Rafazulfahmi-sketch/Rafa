"use client";

import Image from "next/image";
import { motion, AnimatePresence } from "motion/react";

export default function AboutSection() {
  return (
    <section className="bg-[#00488E] py-8 md:py-20 overflow-hidden">
      <div className="container mx-auto px-6 md:px-16">
        <div className="flex flex-col lg:flex-row items-center text-justify md:text-left justify-center md:justify-between gap-10 md:gap-14">
          <div className="flex flex-col gap-6 md:gap-11 w-full lg:max-w-173">
            <motion.div
              initial={{ x: -120, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3, ease: "easeOut" }}
              className="flex flex-col md:text-left text-center"
            >
              <h2 className="font-bold text-xl md:text-4xl leading-normal text-white uppercase">
                APA ITU OSIS MILLENIUM?
              </h2>
              <p className="font-semibold text-xs leading-normal text-white/80">
                Organisasi ini bertujuan mempersiapkan siswa.
              </p>
            </motion.div>
            <motion.p
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.6, ease: "easeOut" }}
              className="font-poppins font-normal text-sm leading-normal text-white max-w-145"
            >
              OSIS Millenium merupakan organisasi siswa intra sekolah di SMKN 1
              Cibinong yang menjadi wadah pengembangan minat, bakat, dan
              kreativitas siswa. Melalui berbagai program dan kegiatan, OSIS.
              OSIS Millenium mendorong siswa untuk aktif berpartisipasi, berani
              berkreasi, serta melatih kepemimpinan dan kerja sama demi
              terciptanya lingkungan sekolah yang positif and dinamis.
            </motion.p>
          </div>
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.6, ease: "easeOut" }}
            className="relative w-full md:w-xl md:h-117 h-60 rounded-md overflow-hidden shrink-0"
          >
            <AnimatePresence mode="wait">
              <motion.div
                initial={{ x: 200, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -200, opacity: 0 }}
                transition={{ duration: 0.7, ease: "easeInOut" }}
                className="absolute inset-0"
              >
                <Image
                  src="/assets/home/about-photo.png"
                  alt="Kegiatan OSIS"
                  fill
                  className="object-cover"
                />
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
