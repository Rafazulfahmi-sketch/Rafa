"use client";

import Image from "next/image";
import { motion } from "motion/react";
import { Button } from "../ui/button";
import Link from "next/link";
import { CustomDialog } from "../fragments/DetailDialog";

import { useAllPrograms } from "@/hooks/useApi";

export default function ProgramSection() {
  const { data: programsData, loading } = useAllPrograms(6);

  const programs = programsData.map(p => ({
    image: p.image || "/assets/home/programs/top-left.png",
    name: p.name,
    detail: p.description,
    coordinator: p.department_name,
    date: new Date(), // API doesn't seem to return date for programs, using current date
  }));

  if (loading && programs.length === 0) {
    return null; // Or skeleton
  }

  return (
    <section className="pb-15 md:pb-30">
      <div className="container mx-auto px-6 md:px-16">
        <div className="text-center flex flex-col justify-center items-center mb-6 md:mb-12 gap-2 md:gap-2">
          <motion.h2
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: 0.4, ease: "easeOut" }}
            className="font-bold text-xl md:text-4xl leading-[1.2] text-[#1A1A1A]"
          >
            PROGRAM KERJA
          </motion.h2>
          <motion.p
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.7, ease: "easeOut" }}
            className="font-poppins md:w-xl font-normal text-xs md:text-base leading-normal text-[#1A1A1A]"
          >
            Langkah nyata OSIS dalam menciptakan lingkungan sekolah yang aktif,
            kreatif, dan berprestasi.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {programs.map((program, index) => (
            <CustomDialog
              data={{ achiever: program.coordinator || "", ...program }}
              key={index}
            >
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.4,
                  delay: 0.0 + (index + 1) * 0.2,
                  ease: "easeOut",
                }}
                className="relative w-full md:h-auto min-h-40 aspect-880/620 rounded-sm duration-150 hover:scale-102 transition-transform hover:shadow-xl cursor-pointer"
              >
                <Image
                  src={program.image}
                  alt={program.name}
                  fill
                  className="object-cover"
                />
                <p className="absolute bottom-0 left-0 bg-black/50 p-2 pr-5 rounded-bl-sm text-white font-semibold text-sm">
                  {program.name}
                </p>
              </motion.div>
            </CustomDialog>
          ))}
        </div>
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{
            duration: 0.6,
            delay: 0.5,
            ease: "easeOut",
          }}
          className="flex justify-center w-full mt-4"
        >
          <Button
            className="bg-[#00509E] font-poppins w-fit font-medium rounded-sm text-xs md:text-base py-2 text-white hover:bg-[#003d7a] transition-colors"
            asChild
          >
            <Link href="/program-kerja">Lihat Program Kerja lebih banyak</Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
