"use client";

import Image from "next/image";
import VisiMisiCard from "../fragments/VisiMisiCard";
import { motion } from "motion/react";

import { useAboutContent } from "@/hooks/useApi";

export default function VisiMisiSection() {
  const { data: visionData } = useAboutContent("vision");
  const { data: missionData } = useAboutContent("mission");

  // Default values
  let visi =
    visionData?.content ||
    "Menjadi organisasi siswa yang religius, berkarakter, inklusif, dan berprestasi...";
  let misi =
    missionData?.content ||
    "Menyelenggarakan pembinaan berkelanjutan untuk meningkatkan keimanan...";
  let image = "/assets/home/tujuan-vismis.png";

  return (
    <section className="px-6 md:px-10 lg:px-16 py-15 md:py-24 lg:py-30">
      <div className="container mx-auto">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 md:gap-12">
          <div className="flex flex-col w-full lg:w-3/4 md:gap-0 gap-2">
            <motion.h2
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.5, ease: "easeOut" }}
              className="font-bold text-2xl md:text-3xl lg:text-4xl leading-[1.2] text-[#1A1A1A] mb-4"
            >
              TUJUAN, VISI, DAN MISI
            </motion.h2>

            <motion.p
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.8, ease: "easeOut" }}
              className="font-poppins font-normal md:text-left text-justify text-sm md:text-base leading-relaxed text-[#1A1A1A] mb-6"
            >
              Tujuan OSIS SMKN 1 Cibinong adalah mempersiapkan peserta didik
              sebagai generasi penerus bangsa yang beriman, berakhlak mulia,
              cerdas, dan berkarakter melalui pengembangan potensi akademik dan
              nonakademik, kepemimpinan, kreativitas, serta kebugaran jasmani
              dalam lingkungan organisasi yang positif, bermoral, toleran, dan
              kolaboratif.
            </motion.p>

            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 1.2, ease: "easeOut" }}
              className="relative w-full aspect-video h-80 rounded-[6px] overflow-hidden"
            >
              <Image
                src={image}
                alt="Kegiatan OSIS"
                fill
                className="object-cover object-center"
              />
            </motion.div>
          </div>

          <div className="grid md:grid-cols-1 gap-4 md:gap-6 w-full lg:w-1/4">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.8, ease: "easeOut" }}
            >
              <VisiMisiCard type="visi" content={visi} isClamped={true} />
            </motion.div>
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 1, ease: "easeOut" }}
            >
              <VisiMisiCard type="misi" content={misi} isClamped={true} />
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
