"use client";

import Image from "next/image";
import { motion } from "motion/react";
import { useLandingHeroes } from "@/hooks/useApi";

const HeroSection = () => {
  const { data: heroes, loading } = useLandingHeroes();

  // Fallback images if API has no data
  const defaultImages = {
    leftUp: "/assets/home/hero-left-up.png",
    leftDown: "/assets/home/hero-left-down.png",
    right: "/assets/home/hero-right-clean.png"
  };

  const getHeroImage = (index: number, fallback: string) => {
    return heroes[index]?.image || fallback;
  };

  return (
    <section className="pt-20 md:pt-32 pb-4 md:pb-20">
      <div className="container mx-auto px-6 md:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div className="flex flex-col justify-between gap-4 md:gap-10">
            <motion.div
              initial={{ y: 80, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.6, ease: "easeOut" }}
              className="relative w-full h-50 md:h-96 rounded-md md:rounded-xl overflow-hidden"
            >
              <Image
                src={getHeroImage(0, defaultImages.leftUp)}
                alt="Activities Left Up"
                fill
                className="object-cover"
              />
            </motion.div>
            <motion.div
              initial={{ y: 80, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.6, ease: "easeOut" }}
              className="block md:hidden text-xl font-bold text-center text-black"
            >
              <p>
                Welcome to{" "}
                <span className="text-primary font-extrabold">OSIS</span>{" "}
                Millenium
              </p>
              <p>Official Website</p>
            </motion.div>
            <motion.div
              initial={{ x: -100, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
              className="relative w-full h-65 hidden md:block rounded-md md:rounded-xl overflow-hidden"
            >
              <Image
                src={getHeroImage(1, defaultImages.leftDown)}
                alt="Activities Left Down"
                fill
                className="object-cover"
              />
            </motion.div>
          </div>
          <motion.div
            initial={{ x: 120, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.5, ease: "easeOut" }}
            className="relative w-full h-full rounded-md md:rounded-xl overflow-hidden"
          >
            <Image
              src={getHeroImage(2, defaultImages.right)}
              alt="Activities Right"
              fill
              className="object-cover"
            />
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 1, ease: "easeInOut" }}
              className="absolute bottom-10 left-8 right-8 md:left-7 md:right-7 flex flex-col z-10"
            >
              <h1 className="text-white font-plus-jakarta text-5xl leading-tight font-semibold text-right">
                Welcome, OSIS Millenium
              </h1>
              <h1 className="text-white font-plus-jakarta text-5xl leading-tight font-bold text-left">
                OFFICIAL WEBSITE.
              </h1>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
