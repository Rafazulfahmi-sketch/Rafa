"use client";

import Image from "next/image";
import Link from "next/link";
import { Button } from "../ui/button";
import { motion } from "motion/react";
import { CustomDialog } from "../fragments/DetailDialog";
import { useLandingAchievements } from "@/hooks/useApi";
import { getImageUrl } from "@/lib/utils";

export default function AchievementSection() {
  const { data: achievements, loading } = useLandingAchievements();

  // Divide achievements into top and bottom rows
  const topRowAchievements = achievements.slice(0, 3).map((a) => ({
    image: a.thumbnail || "/assets/home/achievements/achievement-1.png",
    name: a.title,
    detail: a.description,
    achiever: a.participant,
    date: new Date(a.date),
  }));

  const bottomRowAchievements = achievements.slice(3, 5).map((a) => ({
    image: a.thumbnail || "/assets/home/achievements/achievement-1.png",
    name: a.title,
    detail: a.description,
    achiever: a.participant,
    date: new Date(a.date),
  }));

  if (loading && achievements.length === 0) {
    return null; // Or skeleton
  }

  return (
    <section className="md:py-30 py-10">
      <div className="container mx-auto px-6 md:px-16">
        <div className="flex flex-col gap-4 md:gap-8 items-center">
          <div className="text-center md:space-y-0 space-y-2">
            <motion.h2
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.4, ease: "easeOut" }}
              className="font-bold text-lg md:text-4xl leading-normal text-[#1A1A1A]"
            >
              PEROLEHAN PRESTASI MURID SMKN 1 CIBINONG
            </motion.h2>
            <motion.p
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.7, ease: "easeOut" }}
              className="font-poppins text-xs md:text-base md:w-xl leading-normal text-[#1A1A1A] mx-auto"
            >
              Capaian prestasi siswa SMKN 1 Cibinong sebagai hasil kolaborasi
              dan dukungan seluruh warga sekolah
            </motion.p>
          </div>

          <div className="flex flex-col gap-5 md:gap-10 items-center w-full">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 w-full">
              {topRowAchievements.map((achievement, index) => (
                <CustomDialog data={achievement} key={index}>
                  <motion.div
                    initial={{ y: 30, opacity: 0 }}
                    whileInView={{ y: 0, opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{
                      duration: 0.6,
                      delay: 0.0 + (index + 1) * 0.1,
                      ease: "easeOut",
                    }}
                    className="relative cursor-pointer transition-transform duration-150 hover:scale-105 w-full aspect-video rounded-sm overflow-hidden"
                  >
                    <Image
                      src={achievement.image}
                      alt={achievement.name}
                      fill
                      className="object-cover"
                    />
                    <p className="absolute bottom-0 left-0 bg-black/50 p-2 pr-5 text-white font-semibold text-sm">
                      {achievement.name}
                    </p>
                  </motion.div>
                </CustomDialog>
              ))}
            </div>
            {bottomRowAchievements.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-225">
                {bottomRowAchievements.map((achievement, index) => (
                  <CustomDialog data={achievement} key={index}>
                    <motion.div
                      initial={{ y: 30, opacity: 0 }}
                      whileInView={{ y: 0, opacity: 1 }}
                      viewport={{ once: true }}
                      transition={{
                        duration: 1.4,
                        delay: 0.1 + (index + 1) * 0.1,
                        ease: "easeOut",
                      }}
                      className="relative cursor-pointer transition-transform duration-150 hover:scale-105 w-full aspect-video rounded-sm overflow-hidden"
                    >
                      <Image
                        src={achievement.image}
                        alt={achievement.name}
                        fill
                        className="object-cover"
                      />
                      <p className="absolute bottom-0 left-0 bg-black/50 p-2 pr-5 text-white font-semibold text-sm">
                        {achievement.name}
                      </p>
                    </motion.div>
                  </CustomDialog>
                ))}
              </div>
            )}
          </div>

          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.6,
              delay: 0.5,
              ease: "easeOut",
            }}
          >
            <Button
              className="bg-[#00509E] font-poppins w-fit font-medium rounded-sm text-xs md:text-base py-2 text-white hover:bg-[#003d7a] transition-colors"
              asChild
            >
              <Link href="/perolehan-prestasi">
                Lihat prestasi lebih banyak
              </Link>
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
