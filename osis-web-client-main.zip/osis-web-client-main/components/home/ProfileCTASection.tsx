"use client";

import Image from "next/image";
import Link from "next/link";
import { Button } from "../ui/button";
import { ArrowRight } from "lucide-react";
import { motion } from "motion/react";

export default function ProfileCTASection() {
  return (
    <section className="relative md:py-0 py-10 md:pt-10 overflow-hidden">
      <div className="absolute inset-0 w-screen scale-105 h-full">
        <Image
          src="/assets/home/profile-bg.png"
          alt="Profile Background"
          fill
          className="object-cover"
          priority
        />
      </div>

      <div className="container mx-auto px-6 md:px-16 relativez-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="flex flex-col md:items-start items-center gap-6 md:gap-5 max-w-186">
            <motion.h2
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3, ease: "easeOut" }}
              className="font-poppins font-extrabold text-center md:text-left text-lg md:text-4xl leading-normal uppercase text-white drop-shadow-sm"
            >
              <span className="block whitespace-nowrap">
                Mengenal Profil Pengurus
              </span>
              <span className="block">OSIS lebih dalam</span>
            </motion.h2>
            <motion.p
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.5, ease: "easeOut" }}
              className="font-poppins font-normal leading-normal text-justify md:text-left text-white max-w-xl text-sm drop-shadow-sm"
            >
              OSIS merupakan wadah bagi siswa-siswi yang berperan aktif dalam
              mengembangkan kegiatan positif di lingkungan sekolah. Melalui
              kerja sama dan tanggung jawab bersama, para pengurus OSIS
              merancang serta menjalankan berbagai program kerja yang edukatif
              dan inspiratif sebagai sarana pengembangan bakat, kepemimpinan,
              dan karakter siswa. Mari mengenal profil pengurus OSIS lebih
              dekat.
            </motion.p>

            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.6, ease: "easeOut" }}
              className="z-2 "
            >
              <Button
                asChild
                size={"lg"}
                className="gap-3 bg-white hover:bg-white/90 font-poppins font-semibold leading-normal text-[#FFC107] w-fit transition-colors shadow-md"
              >
                <Link href="/struktur-organisasi">
                  Lihat Profil Pengurus <ArrowRight />
                </Link>
              </Button>
            </motion.div>
          </div>

          <div className="relative w-full hidden  right-1/2 h-126 shrink-0 md:flex items-end justify-end">
            <Image
              src="/assets/home/profile-photo-v3.png"
              alt="Pengurus OSIS"
              width={500}
              height={500}
              quality={100}
              className="object-contain size-130 object-bottom"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
