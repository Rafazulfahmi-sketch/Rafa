import HeroSection from "@/components/tentang-millenium/HeroSection";
import ManfaatSection from "@/components/tentang-millenium/ManfaatSection";
import PesanPembinaSection from "@/components/tentang-millenium/PesanPembinaSection";
import SifatAsasSection from "@/components/tentang-millenium/SifatAsasSection";
import VisiMisiSection from "@/components/tentang-millenium/VisiMisiSection";
import React from "react";

const TentangMilleniumLayout = () => {
  return (
    <main className="min-h-screen pt-20 md:pt-32 pb-20 px-6 md:px-8 md:mx-20">
      <HeroSection />
      <VisiMisiSection />
      <SifatAsasSection />
      <ManfaatSection />
      <PesanPembinaSection />
    </main>
  );
};

export default TentangMilleniumLayout;