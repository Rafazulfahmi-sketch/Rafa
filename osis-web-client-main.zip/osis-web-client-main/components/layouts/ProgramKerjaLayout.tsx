"use client";

import { useState } from "react";
import MainPagination from "@/components/fragments/MainPagination";
import { Button } from "@/components/ui/button";
import ProgramKerjaGrid from "../program-kerja/ProgramKerjaGrid";

import { useAllPrograms } from "@/hooks/useApi";

const ProgramKerjaLayout = () => {
  const [sortNewest, setSortNewest] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [limit, setPerPage] = useState<number>(10);
  const { data: programsNested, loading } = useAllPrograms();

  // Flatten nested data from useAllPrograms
  const allProgramsFlattened = (programsNested as any[]).flatMap((dept) =>
    dept.programs.map((p: any) => ({
      ...p,
      department_name: dept.department_name,
    })),
  );

  const sorted = [...allProgramsFlattened].sort((a, b) => {
    return sortNewest ? b.id - a.id : a.id - b.id; // Fallback to ID sort
  });

  const totalPages = Math.ceil(sorted.length / limit) || 1;
  const paginatedData = sorted.slice((page - 1) * limit, page * limit);

  return (
    <main className="min-h-screen pt-22 pb-12 md:pt-25 md:pb-22">
      <div className="container mx-auto px-4 md:px-8 lg:px-16">
        <div className="w-full text-left mb-10 md:mb-12">
          <h1 className="font-poppins font-semibold text-xl md:text-4xl lg:text-[40px] leading-tight text-black mb-2 md:mb-1 uppercase drop-shadow-sm">
            PROGRAM KERJA OSIS SMKN 1 CIBINONG
          </h1>
          <p className="font-poppins font-normal text-sm md:text-base md:leading-relaxed text-black/80 max-w-4xl">
            Langkah nyata OSIS dalam menciptakan lingkungan sekolah yang aktif,
            kreatif, dan berprestasi melalui berbagai program kerja unggulan.
          </p>
        </div>
        <div className="flex justify-start mb-6">
          <Button
            className="border-primary bg-primary text-white rounded-md font-semibold"
            onClick={() => setSortNewest(!sortNewest)}
          >
            Sort: {sortNewest ? "Terbaru" : "Terlama"}
          </Button>
        </div>
        <ProgramKerjaGrid data={paginatedData} loading={loading} />
        {totalPages > 1 && (
          <MainPagination
            page={page}
            perPage={limit}
            setPerPage={setPerPage}
            totalPages={totalPages}
            setPage={setPage}
          />
        )}
      </div>
    </main>
  );
};

export default ProgramKerjaLayout;
