"use client";

import { useEffect, useState } from "react";
import PrestasiHeader from "@/components/perolehan-prestasi/PrestasiHeader";
import PrestasiGrid from "@/components/perolehan-prestasi/PrestasiGrid";
import PrestasiPagination from "@/components/fragments/MainPagination";
import { Button } from "../ui/button";

import { useLandingAchievements } from "@/hooks/useApi";

const PerolehanPrestasiLayout = () => {
  const [sortNewest, setSortNewest] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [limit, setPerPage] = useState<number>(10);
  const { data: achievements, loading } = useLandingAchievements();

  // Sort and Paginate (Client-side for now, as API doesn't seem to support it yet)
  const sorted = [...achievements].sort((a, b) => {
    const dateA = new Date(a.date).getTime();
    const dateB = new Date(b.date).getTime();
    return sortNewest ? dateB - dateA : dateA - dateB;
  });

  const totalPages = Math.ceil(sorted.length / limit) || 1;
  const paginatedData = sorted.slice((page - 1) * limit, page * limit);

  return (
    <main className="min-h-screen pt-22 pb-12 md:pt-25 md:pb-22">
      <div className="container mx-auto px-4 md:px-8 lg:px-16">
        <PrestasiHeader />
        <div className="flex justify-start mb-6">
          <Button
            className="border-primary bg-primary text-white rounded-md font-semibold"
            onClick={() => setSortNewest(!sortNewest)}
          >
            Sort: {sortNewest ? "Terbaru" : "Terlama"}
          </Button>
        </div>
        <PrestasiGrid data={paginatedData} loading={loading} />
        {totalPages > 1 && (
          <PrestasiPagination
            page={page}
            perPage={limit}
            setPerPage={setPerPage}
            totalPages={totalPages}
            setPage={setPage}
          />
        )}
      </div>
    </main>
  );
};

export default PerolehanPrestasiLayout;
