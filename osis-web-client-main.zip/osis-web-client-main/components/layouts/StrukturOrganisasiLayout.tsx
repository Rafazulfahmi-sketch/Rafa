import BPHSection from "@/components/struktur-organisasi/BPHSection";
import HeroSection from "@/components/struktur-organisasi/HeroSection";
import PembinaSection from "@/components/struktur-organisasi/PembinaSection";
import SeksiBidangSection from "@/components/struktur-organisasi/SeksiBidangSection";
import React from "react";

const StrukturOrganisasiLayout = () => {
  return (
    <main className="bg-[#F5F5F5] min-h-screen mt-10 bg-[linear-gradient(to_right,#0206181e,transparent_1px),linear-gradient(to_bottom,#0206181e,transparent_1px)] bg-size-[40px_40px]">
      <HeroSection />
      <div className="flex flex-col gap-15 md:gap-20 md:py-20 ">
        <PembinaSection />
        <BPHSection />
        <SeksiBidangSection />
      </div>
    </main>
  );
};

export default StrukturOrganisasiLayout;
