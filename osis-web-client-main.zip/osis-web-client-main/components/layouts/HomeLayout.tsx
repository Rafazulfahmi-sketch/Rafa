import HeroSection from "@/components/home/HeroSection";
import HomeContent from "@/components/home/HomeContent";

export default function HomeLayout() {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <HomeContent />
    </main>
  );
}
