"use client";

import Image from "next/image";
import { ReactNode } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { format } from "date-fns";

export interface AchievementData {
  image: string;
  name: string;
  detail: string;
  achiever: string | { name: string; className?: string };
  date: Date;
}

interface CustomDialogProps {
  data: AchievementData;
  children: ReactNode;
}

export function CustomDialog({ data, children }: CustomDialogProps) {
  const achieverName =
    typeof data.achiever === "string" ? data.achiever : data.achiever.name;

  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>

      <DialogContent className="p-6 md:min-w-3xl rounded-md">
        <DialogHeader className="hidden">
          <DialogTitle className="sr-only">{data.name}</DialogTitle>
        </DialogHeader>
        <div className="w-full grid md:grid-cols-2 gap-4 md:gap-6 items-start">
          <div className="relative w-full h-full aspect-video md:aspect-auto rounded-xs md:rounded-sm overflow-hidden">
            <Image
              src={data.image}
              alt={data.name}
              fill
              className="object-cover "
            />
          </div>
          <div className="flex flex-col w-full gap-2">
            <h2 className="text-lg md:text-2xl font-semibold md:font-bold">{data.name}</h2>

            <p className="text-[10px] md:text-xs text-primary font-bold">
              {format(data.date, "dd/MM/yyyy")}
            </p>

            <p className="text-black/80 text-xs md:text-sm leading-relaxed">
              {data.detail}
            </p>

            <div className="border-t pt-4 mt-4">
              <p className="text-sm md:text-base font-medium text-blue-700">
                {achieverName}
              </p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
