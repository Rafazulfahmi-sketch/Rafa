"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";

const NAV_ITEMS = [
  { label: "Beranda", href: "/" },
  { label: "Struktur Organisasi", href: "/struktur-organisasi" },
  { label: "Prestasi Murid", href: "/perolehan-prestasi" },
  { label: "Tentang MILLENIUM", href: "/tentang-millenium" },
];

export default function Navbar() {
  const pathname = usePathname();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="container mx-auto px-6 md:px-16 py-1 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center ">
            <div className="relative md:w-12 md:h-11 h-8 w-8">
              <Image
                src="/assets/home/logo-sekolah.png"
                alt="Logo Sekolah"
                fill
                className="object-contain"
              />
            </div>
            <div className="relative md:w-17 md:h-17 w-11 h-12">
              <Image
                src="/assets/home/logo-osis.png"
                alt="Logo OSIS"
                fill
                className="object-contain"
              />
            </div>
          </Link>
          <div className="flex flex-col justify-center">
            <span className="text-sm md:text-base font-semibold font-poppins text-black leading-tight">
              OSIS SMKN 1 CIBINONG
            </span>
            <span className="text-sm font-medium font-poppins text-black leading-tight">
              OFFICIAL WEBSITE
            </span>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-5">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-medium font-poppins text-black hover:opacity-75 transition-opacity"
            >
              {item.label}
            </Link>
          ))}
        </div>
        <button
          className="md:hidden p-2 text-black"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <AnimatePresence mode="wait">
            {isMobileMenuOpen ? (
              <motion.span
                key="close"
                initial={{ rotate: -90, opacity: 0, scale: 0.8 }}
                animate={{ rotate: 0, opacity: 1, scale: 1 }}
                exit={{ rotate: 90, opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.2 }}
                className="inline-block"
              >
                <X className="w-6 h-6" />
              </motion.span>
            ) : (
              <motion.span
                key="menu"
                initial={{ rotate: 90, opacity: 0, scale: 0.8 }}
                animate={{ rotate: 0, opacity: 1, scale: 1 }}
                exit={{ rotate: -90, opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.2 }}
                className="inline-block"
              >
                <Menu className="w-6 h-6" />
              </motion.span>
            )}
          </AnimatePresence>
        </button>
      </div>

      <AnimatePresence mode="wait">
        {isMobileMenuOpen && (
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{
              y: isMobileMenuOpen ? 0 : -20,
              opacity: isMobileMenuOpen ? 1 : 0,
            }}
            transition={{ delay: 0.2, duration: 0.2, ease: "easeInOut" }}
            className="md:hidden bg-white border-t border-gray-100 absolute w-full shadow-lg"
          >
            <div className="flex flex-col p-6 gap-4">
              {NAV_ITEMS.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="text-base font-medium font-poppins text-black"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
