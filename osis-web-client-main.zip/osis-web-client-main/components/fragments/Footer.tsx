"use client";

import Image from "next/image";
import Link from "next/link";

const Footer = () => {
  return (
    <footer className="bg-transparent text-white relative">
      <div className="relative w-full">
        <div className="absolute inset-0 w-full h-full -z-10">
          <Image
            src="/assets/home/footer/footer-wave.svg"
            alt="Footer Wave"
            fill
            className="object-cover object-top"
            priority
          />
        </div>

        <div className="container mx-auto px-4 pt-32 pb-8 md:pt-48 md:pb-14 flex flex-col items-center justify-center text-center space-y-5">
          <h2 className="font-montserrat font-semibold md:font-bold text-sm md:text-lg leading-normal max-w-4xl drop-shadow-sm text-[#FAF9F6]">
            Banyak pengalaman dan koneksi yang bisa kalian dapatkan
            <br className="hidden md:block" />
            dengan mengikuti kepengurusan OSIS.
          </h2>
          <p className="font-montserrat font-semibold md:font-bold text-sm md:text-lg leading-normal drop-shadow-sm text-[#FAF9F6]">
            Ayo join sekarang!
          </p>
        </div>
      </div>

      <div className="bg-[#00509E] w-full pb-10 -mt-2">
        <div className="container mx-auto px-6 md:px-16 pt-8 md:pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center md:items-start gap-4 md:gap-8 mb-5 w-full max-w-full mx-auto mt-2">
            <div className="flex items-center gap-1">
              <div className="relative w-14 h-14 md:w-18 md:h-18">
                <Image
                  src="/assets/home/logo-sekolah.png"
                  alt="Logo OSIS"
                  fill
                  className="object-contain"
                />
              </div>
              <div className="flex flex-col">
                <p className="font-poppins font-normal pt-5 text-[10px] md:text-[14px] text-white leading-tight">
                  Di bawah bimbingan dan pengawasan
                </p>
                <div className="flex items-center gap-2">
                  <div className="relative w-8 h-8 md:w-14 md:h-14">
                    <Image
                      src="/assets/home/logo-osis.png"
                      alt="Logo Sekolah"
                      fill
                      className="object-contain"
                    />
                  </div>
                  <p className="font-poppins font-medium text-xs md:text-[14px] text-white leading-tight">
                    SMKN 1 Cibinong
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center gap-2 mr-0 md:mr-12">
              <h3 className="font-montserrat font-medium md:font-semibold text-xs md:text-base mb-1">
                Contact Us!
              </h3>
              <div className="flex items-center gap-3">
                <Link
                  href="https://www.instagram.com/osissmkn1cbn/"
                  className="relative w-5 h-5 md:w-9 md:h-9 hover:scale-110 transition-transform"
                >
                  <Image
                    src="/assets/home/footer/icon-instagram.svg"
                    alt="Instagram"
                    fill
                    className="object-contain"
                  />
                </Link>
                <Link
                  href="https://www.tiktok.com/@osissmkn1cbn"
                  className="relative w-5 h-5 md:w-9 md:h-9 hover:scale-110 transition-transform"
                >
                  <Image
                    src="/assets/home/footer/icon-tiktok.svg"
                    alt="TikTok"
                    fill
                    className="object-contain"
                  />
                </Link>
                {/* Email */}
                <Link
                  href="mailto:osis@smkn1cibinong.sch.id"
                  className="relative w-5 h-5 md:w-9 md:h-9 hover:scale-110 transition-transform"
                >
                  <Image
                    src="/assets/home/footer/icon-email.svg"
                    alt="Email"
                    fill
                    className="object-contain"
                  />
                </Link>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-center">
            <div className="w-full max-w-full h-1px bg-white mb-6"></div>
            <p className="font-montserrat font-medium text-[9px] md:text-xs leading-normal text-white">
              © 2026 OSIS SMKN 1 Cibinong. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
