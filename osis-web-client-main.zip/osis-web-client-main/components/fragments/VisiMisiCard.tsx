import { sanitizeHtml } from "@/utils/sanitize";
import { cn } from "@/lib/utils";

const VisiMisiCard = ({
  type,
  content,
  isClamped = false,
}: {
  type: "visi" | "misi";
  content: string;
  isClamped?: boolean;
}) => {
  const sanitizedContent = sanitizeHtml(content);

  return (
    <div
      className={`${type == "visi" ? "bg-[#FFC107] text-[#1A1A1A]" : "bg-[#00509E] text-white"} rounded-[10px] p-5 flex flex-col justify-around md:h-auto h-fit gap-2`}
    >
      <h3 className="font-poppins font-bold text-lg md:text-3xl">{type.toUpperCase()}</h3>
      <div 
        className={cn(
          "font-poppins font-normal text-justify md:text-left text-xs md:text-sm leading-normal rich-text-content",
          isClamped && "line-clamp-6"
        )}
        dangerouslySetInnerHTML={{ __html: sanitizedContent }}
      />
    </div>
  );
};

export default VisiMisiCard;
