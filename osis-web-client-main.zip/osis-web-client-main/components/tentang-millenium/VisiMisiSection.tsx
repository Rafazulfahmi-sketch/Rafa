'use client'

import React from "react";
import VisiMisiCard from "../fragments/VisiMisiCard";
import { motion } from "motion/react";

import { useAboutContent } from "@/hooks/useApi";

const VisiMisiSection: React.FC = () => {
  const { data: visionData } = useAboutContent("vision");
  const { data: missionData } = useAboutContent("mission");

  const vision = visionData?.content || "Menjadi organisasi siswa yang religius, berkarakter, inklusif, dan berprestasi...";
  const mission = missionData?.content || "Menyelenggarakan pembinaan berkelanjutan untuk meningkatkan keimanan...";

  return (
    <section className="md:px-0 mb-20 md:mb-32 my-15">
      <div className="flex flex-col md:flex-row justify-center items-stretch gap-5 md:gap-10">
        <motion.div
          initial={{ x: -120, opacity: 0 }}
          whileInView={{ x: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
          className="w-full h-full"
        >
          <VisiMisiCard
            type="visi"
            content={vision}
          />
        </motion.div>
        <motion.div
          initial={{ x: 120, opacity: 0 }}
          whileInView={{ x: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.7, ease: "easeOut" }}
          className="w-full h-full"
        >
          <VisiMisiCard
            type="misi"
            content={mission}
          />
        </motion.div>
      </div>
    </section>
  );
};

export default VisiMisiSection;
