"use client";

import Image from "next/image";
import React from "react";
import { motion } from "motion/react";

import { useActiveAdvisors } from "@/hooks/useApi";

const PesanPembinaSection: React.FC = () => {
  const { data: advisors } = useActiveAdvisors();
  const advisor = advisors[0]; // Assuming first advisor for this section

  if (!advisor) return null;

  return (
    <section className="container mx-auto px-4 md:px-6 lg:px-8 py-20 md:py-10">
      <div className="flex flex-col md:flex-row md:items-start gap-10 md:gap-16">
        <div className="flex flex-col w-full md:w-2/3 gap-6">
          <div className="order-1 md:order-0 text-center md:text-left">
            <motion.h2
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
              className="font-poppins font-semibold md:font-bold text-xl md:text-3xl leading-tight uppercase"
            >
              Pesan dan Kata Sambutan oleh
              <br className="hidden md:block" />
              Pembina OSIS MPPK periode 2025/2026
            </motion.h2>

            <motion.h3
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
              className="font-poppins font-semibold text-lg md:text-xl text-[#00509E] mt-2"
            >
              {advisor.name}
            </motion.h3>
          </div>
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
            className="relative w-55 h-55 mx-auto md:hidden order-2 border-b-2"
          >
            <Image
              src={advisor.image || "/assets/tentang-millenium/pembina-image.png"}
              alt={`${advisor.name} - Pembina OSIS`}
              fill
              className="object-contain drop-shadow-md"
              sizes="220px"
            />
          </motion.div>

          {/* PARAGRAPH */}
          <motion.p
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.6, ease: "easeOut" }}
            className="order-3 md:order-0 font-jakarta font-medium text-sm md:text-base leading-relaxed text-justify md:text-left"
          >
            {advisor.message}
          </motion.p>
        </div>
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
          className="hidden md:block relative md:w-85 md:h-85 lg:w-95 lg:h-95 shrink-0"
        >
          <Image
            src={advisor.image || "/assets/tentang-millenium/pembina-image.png"}
            alt={`${advisor.name} - Pembina OSIS`}
            fill
            className="object-contain drop-shadow-md"
            sizes="(max-width: 1024px) 340px, 380px"
          />
        </motion.div>
      </div>
    </section>
  );
};

export default PesanPembinaSection;
