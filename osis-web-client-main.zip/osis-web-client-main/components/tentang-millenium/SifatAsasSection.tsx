"use client";

import Image from "next/image";
import React from "react";
import { motion } from "motion/react";

import { useAboutContent } from "@/hooks/useApi";
import { sanitizeHtml } from "@/utils/sanitize";

const SifatAsasSection: React.FC = () => {
  const { data: sifatData } = useAboutContent("sifat");
  const { data: asasData } = useAboutContent("asas");

  const sanitizedSifat = sanitizeHtml(sifatData?.content || "");
  const sanitizedAsas = sanitizeHtml(asasData?.content || "");

  return (
    <section className="container mx-auto md:py-20 md:space-y-25">
      <div className="grid md:grid-cols-2 gap-10 md:gap-16 items-center md:border-0 border-b-2 border-[#FFC107] pb-10 md:pb-0">
        <div className="space-y-4">
          <motion.h2
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2, ease: "easeOut" }}
            className="text-2xl md:text-4xl font-semibold md:font-bold font-poppins"
          >
            SIFAT
          </motion.h2>
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4, ease: "easeOut" }}
            className="md:space-y-4 space-y-2 text-xs md:text-base font-semibold font-jakarta leading-relaxed md:text-left text-justify rich-text-content"
            dangerouslySetInnerHTML={{ __html: sanitizedSifat || "Sifat OSIS Millenium..." }}
          />
        </div>
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          whileInView={{ scale: 1, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
          className="relative w-full h-60 md:h-80 rounded-sm md:rounded-md shadow overflow-hidden"
        >
          <Image
            src={sifatData?.image || "/assets/tentang-millenium/sifat-image.png"}
            alt="Sifat OSIS Millenium"
            fill
            className="object-cover"
            priority={false}
          />
        </motion.div>
      </div>

      <div className="grid md:grid-cols-2 gap-10 md:gap-16 items-center pt-10 md:pt-0">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          whileInView={{ scale: 1, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
          className="relative w-full h-60 md:h-80 rounded-sm md:rounded-md shadow overflow-hidden order-2 md:order-1"
        >
          <Image
            src={asasData?.image || "/assets/tentang-millenium/asas-image.png"}
            alt="Asas OSIS Millenium"
            fill
            className="object-cover"
          />
        </motion.div>
        <div className="space-y-4 order-1 md:order-2">
          <motion.h2
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2, ease: "easeOut" }}
            className="text-2xl md:text-4xl font-semibold md:font-bold font-poppins"
          >
            ASAS
          </motion.h2>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4, ease: "easeOut" }}
            className="md:space-y-4 md:text-left text-justify space-y-2 text-xs md:text-base font-semibold font-jakarta leading-relaxed rich-text-content"
            dangerouslySetInnerHTML={{ __html: sanitizedAsas || "Asas OSIS Millenium..." }}
          />
        </div>
      </div>
    </section>
  );
};

export default SifatAsasSection;
