"use client";

import Image from "next/image";
import React from "react";
import { motion } from "motion/react";

import { useLandingHeroes } from "@/hooks/useApi";

const HeroSection: React.FC = () => {
  const { data: heroes } = useLandingHeroes();
  const heroImage = heroes[3]?.image || "/assets/tentang-millenium/hero-image.png";

  return (
    <section className="container mx-auto w-full flex flex-col items-center">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        whileInView={{ y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.4, delay: 0.2, ease: "easeOut" }}
        className="flex flex-col items-center w-full"
      >
        <h1 className="font-poppins font-semibold text-xl md:text-4xl md:tracking-[0.06em] text-center leading-normal text-black">
          TENTANG OSIS MILLENIUM
        </h1>
        <h2 className="font-jakarta font-semibold text-sm md:text-base tracking-[0.06em] text-center text-black">
          SMKN 1 CIBINONG
        </h2>
      </motion.div>
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        whileInView={{ y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.6, ease: "easeOut" }}
        className="relative w-full max-w-full h-50 md:h-150"
      >
        <Image
          src={heroImage}
          alt="Hero Tentang Millenium"
          fill
          className="object-contain aspect-video"
          priority
        />
      </motion.div>
      <motion.p
        initial={{ y: 20, opacity: 0 }}
        whileInView={{ y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.4, ease: "easeOut" }}
        className="font-poppins font-medium text-justify text-xs md:text-base md:text-center text-black max-w-full"
      >
        OSIS Millenium merupakan organisasi siswa intra sekolah di SMKN 1
        Cibinong yang menjadi wadah pengembangan minat, bakat, dan kreativitas
        siswa. Melalui berbagai program dan kegiatan, OSIS. OSIS Millenium
        mendorong siswa untuk aktif berpartisipasi, berani berkreasi, serta
        melatih kepemimpinan dan kerja sama demi terciptanya lingkungan sekolah
        yang positif dan dinamis.
      </motion.p>
    </section>
  );
};

export default HeroSection;
