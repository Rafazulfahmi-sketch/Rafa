"use client";
import {
  Axe,
  BarChart3,
  Brain,
  ClipboardList,
  Dumbbell,
  MessageCircle,
  Star,
  Users,
} from "lucide-react";
import React from "react";
import { motion } from "motion/react";

const ManfaatSection: React.FC = () => {
  const benefits = [
    {
      title: "Manajemen Skala Prioritas",
      icon: BarChart3,
      variant: "primary",
    },
    {
      title: "Melatih Manajemen Waktu",
      icon: ClipboardList,
      variant: "secondary",
    },
    {
      title: "Melatih Jiwa Kepemimpinan",
      icon: Star,
      variant: "primary",
    },
    {
      title: "Meningkatkan Rasa Tanggung Jawab",
      icon: Dumbbell,
      variant: "secondary",
    },
    {
      title: "Mengasah Skill Komunikasi",
      icon: MessageCircle,
      variant: "primary",
    },
    {
      title: "Belajar Kerja Sama Tim",
      icon: Brain,
      variant: "secondary",
    },
    {
      title: "Memperluas Relasi Pertemanan",
      icon: Users,
      variant: "primary",
    },
    {
      title: "Wadah Melatih Soft Skill dan Hard Skill",
      icon: Axe,
      variant: "secondary",
    },
  ];

  return (
    <section className="container mx-auto px-4 md:px-6 lg:px-8 py-20 md:py-32">
      <div className="text-center space-y-3 mb-10 md:mb-16">
        <motion.h2
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2, ease: "easeOut" }}
          className="text-xl md:text-4xl font-semibold md:font-bold font-poppins md:leading-tight"
        >
          MANFAAT BAGIAN DARI PENGURUS OSIS
        </motion.h2>
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4, ease: "easeOut" }}
          className="text-xs md:text-base font-medium font-jakarta max-w-xl mx-auto"
        >
          Beragam manfaat yang bisa diperoleh ketika menjadi bagian dari
          kepengurusan OSIS
        </motion.p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {benefits.map((item, index) => {
          const Icon = item.icon;

          const isPrimary = item.variant === "primary";

          return (
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.5,
                delay: 0.0 + (index + 1) * 0.1,
                ease: "easeOut",
              }}
              key={index}
              className={`relative p-6 rounded-md shadow-sm h-34 flex flex-col justify-end md:min-h-40
                            ${isPrimary ? "bg-[#00509E] text-white" : "bg-[#FFC107] text-[#272727]"}`}
            >
              <div
                className={`absolute top-5 left-5 p-2 rounded-md
                                ${isPrimary ? "bg-white/20 text-white" : "bg-black/10 text-[#272727]"}`}
              >
                <Icon className="w-5 h-5 md:w-6 md:h-6" />
              </div>
              <h3 className="text-base md:text-lg font-bold font-poppins leading-snug">
                {item.title}
              </h3>
            </motion.div>
          );
        })}
      </div>
      <div className="md:mt-12 mt-5 text-center">
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, delay: 1.5, ease: "easeOut" }}
          className="text-xs md:text-lg md:font-semibold font-poppins"
        >
          Dan Masih Banyak Lagi...
        </motion.p>
      </div>
    </section>
  );
};

export default ManfaatSection;
