"use client";

import Image from "next/image";
import React from "react";
import { SekbidMember } from "@/lib/sekbid-data";
import { motion } from "motion/react";

interface SekbidStrukturProps {
  members: SekbidMember[];
  groupPhoto: string;
  sekbidId: number;
  sekbidTitle: string;
}

const SekbidStruktur = ({
  members,
  groupPhoto,
  sekbidId,
  sekbidTitle,
}: SekbidStrukturProps) => {
  return (
    <div className="relative w-full overflow-hidden">
      <div className="absolute inset-0 bg-[#00509E]">
        <Image
          src="/assets/perolehan-prestasi/perolehan-prestasi.png"
          alt="Background Pattern"
          fill
          className="object-cover opacity-10"
        />
      </div>
      <div className="relative z-10 px-4 md:px-16 lg:px-16.5 py-12 md:py-16">
        <div className="flex flex-col items-center gap-y-10 md:gap-18">
          <div className="flex flex-col items-center gap-0">
            <motion.h2
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
              className="font-poppins font-bold text-xl md:text-3xl  leading-normal uppercase text-white text-center"
            >
              Struktur Kepengurusan
            </motion.h2>
            <motion.p
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
              className="font-plus-jakarta font-normal md:font-medium text-sm md:text-base leading-normal text-white/93 text-center"
            >
              Berisi informasi struktur kepengurusan dalam divisi dan biodata
              para pengurus
            </motion.p>
          </div>
          <div className="flex flex-col items-center gap-15 w-full">
            <div
              className={
                ["Trimitra", "Sekretaris", "Bendahara"].includes(sekbidTitle)
                  ? "flex flex-wrap justify-center gap-5 w-full"
                  : "w-full grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5 justify-items-center"
              }
            >
              {members.map((member, index) => (
                <motion.div
                  initial={{ y: 30, opacity: 0 }}
                  whileInView={{ y: 0, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: 1,
                    delay: 0.0 + (index + 1) * 0.1,
                    ease: "easeOut",
                  }}
                  key={index}
                  className="flex flex-col items-center gap-4"
                >
                  <div className="relative w-37.5 h-50 md:w-53.5 md:h-70 rounded-md overflow-hidden">
                    <Image
                      src={member.photo}
                      alt={member.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="text-center">
                    <p className="font-poppins font-semibold md:font-bold text-xs md:text-sm lg:text-base text-white leading-tight">
                      {member.name}
                    </p>
                    <p className="font-plus-jakarta font-normal text-xs md:text-sm text-white/80 leading-tight mt-1">
                      {member.role}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="flex flex-col items-center gap-5 w-full max-w-250">
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
                className="relative w-full aspect-video md:h-100 overflow-hidden rounded-md"
              >
                <Image
                  src={groupPhoto}
                  alt="Foto Bersama"
                  fill
                  className="object-cover"
                />
              </motion.div>
              <motion.p
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
                className="font-poppins font-semibold md:font-bold text-sm md:text-lg lg:text-2xl leading-normal text-white text-center"
              >
                {sekbidTitle === "Trimitra" ||
                sekbidTitle === "Sekretaris" ||
                sekbidTitle === "Bendahara" ? (
                  sekbidTitle.charAt(0).toUpperCase() + sekbidTitle.slice(1)
                ) : (
                  <p>
                    Seksi Bidang {sekbidId} {sekbidTitle}
                  </p>
                )}
              </motion.p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SekbidStruktur;
