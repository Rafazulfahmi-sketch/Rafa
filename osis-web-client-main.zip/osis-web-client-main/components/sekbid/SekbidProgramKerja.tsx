"use client";

import Image from "next/image";
import React from "react";
import { CustomDialog } from "../fragments/DetailDialog";
import { motion } from "motion/react";

interface ProgramData {
  image: string;
  name: string;
  description: string;
  coordinator: string;
  date: Date;
}

const SekbidProgramKerja = ({
  programs,
}: {
  programs: ProgramData[];
}) => {
  return (
    <div className="w-full pb-8 pt-4 md:pb-12">
      <div className="flex flex-col gap-2">
        <motion.h2
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
          className="font-poppins font-bold text-xl md:text-3xl leading-normal uppercase text-black"
        >
          Program Kerja
        </motion.h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-6">
          {programs.map((program, index) => (
            <CustomDialog
              data={{ 
                achiever: program.coordinator, 
                detail: program.description,
                image: program.image,
                name: program.name,
                date: program.date
              }}
              key={index}
            >
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{
                  duration: 1,
                  delay: 0.0 + (index + 1) * 0.1,
                  ease: "easeOut",
                }}
                className="relative w-full hover:scale-105 duration-150 transition-transform cursor-pointer aspect-square overflow-hidden rounded-sm md:rounded-md"
              >
                <Image
                  src={program.image}
                  alt={program.name}
                  fill
                  className="object-cover"
                />
                <p className="absolute bottom-0 left-0 bg-black/50 p-2 pr-5 text-white font-semibold text-xs md:text-sm">
                  {program.name}
                </p>
              </motion.div>
            </CustomDialog>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SekbidProgramKerja;
