"use client";

import Image from "next/image";
import React from "react";
import { motion } from "motion/react";

interface SekbidHeroProps {
  heroImage: string;
}

const SekbidHero = ({ heroImage }: SekbidHeroProps) => {
  return (
    <div className="pt-4 w-full">
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        whileInView={{ y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
        className="relative w-full h-60 md:h-120 aspect-video overflow-hidden rounded-sm"
      >
        <Image
          src={heroImage}
          alt="Hero Sekbid"
          fill
          className="object-cover"
          priority
        />
      </motion.div>
    </div>
  );
};

export default SekbidHero;
