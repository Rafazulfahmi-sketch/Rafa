"use client";

import Image from "next/image";
import React from "react";
import { motion } from "motion/react";

interface SekbidInfoCardsProps {
  tujuan: string[];
  logo: {
    image: string;
    description: string;
  };
  tugasUtama: string[];
}

const SekbidInfoCards = ({
  tujuan,
  logo,
  tugasUtama,
}: SekbidInfoCardsProps) => {
  return (
    <div className="w-full py-12 md:py-16 lg:py-25">
      <div className="flex flex-col lg:flex-row items-end justify-between gap-5 lg:gap-5">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
          className="relative w-full lg:w-sm h-auto lg:h-64"
        >
          <div className="md:flex hidden absolute top-0 right-0 z-10 w-12.5 h-12.5 bg-[#00509E] border-2 md:border-3 border-[#003C7D] rounded-bl-[10px] items-center justify-center">
            <span className="font-poppins font-semibold text-xl text-white leading-none">
              2
            </span>
          </div>

          <div className="w-full h-full bg-[#FFC107] border-2 md:border-3 border-[#9F6E0E] md:rounded-md rounded-sm px-5 md:px-8.5 py-4 md:py-9 flex items-center">
            <div className="flex flex-col gap-2.5">
              <motion.h3
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.8, ease: "easeOut" }}
                className="font-poppins font-bold text-xl md:text-2xl leading-normal text-[#1A1A1A]"
              >
                Tujuan
              </motion.h3>
              <motion.ol
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.9, ease: "easeOut" }}
                className="font-plus-jakarta font-medium text-xs md:text-sm leading-[1.26] text-[#1A1A1A] list-decimal list-inside space-y-1 md:text-left text-justify"
              >
                {tujuan.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </motion.ol>
            </div>
          </div>
        </motion.div>

        {/* Card 2: Logo */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2, ease: "easeOut" }}
          className="relative w-full lg:w-md h-auto lg:h-75"
        >
          <div className="md:flex hidden absolute top-0 right-0 z-10 w-12.5 h-12.5 bg-[#FFC107] border-[3px] border-[#9F6E0E] rounded-bl-[10px] items-center justify-center">
            <span className="font-poppins font-semibold text-xl text-[#1A1A1A] leading-none">
              1
            </span>
          </div>

          <div className="w-full h-full bg-[#00509E] border-2 md:border-3 border-[#003C77] md:rounded-md rounded-sm px-5 md:px-8.5 py-4 md:py-9 flex flex-col md:flex-row items-center gap-2 md:gap-5">
            <div className="flex flex-col gap-1 md:gap-2.5 flex-1 order-2 md:order-1">
              <motion.h3
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.8, ease: "easeOut" }}
                className="font-poppins font-semibold text-xl md:text-2xl leading-normal text-white"
              >
                Logo
              </motion.h3>

              <motion.p
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.9, ease: "easeOut" }}
                className="font-plus-jakarta font-medium md:text-left text-justify text-xs md:text-sm leading-[1.26] text-white order-3 md:order-2"
              >
                {logo.description}
              </motion.p>
            </div>

            <div className="relative order-1 md:order-2 w-25 h-25 md:w-32 md:h-32 rounded-full overflow-hidden shrink-0">
              <Image
                src={logo.image}
                alt="Logo Sekbid"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </motion.div>

        {/* Card 3: Tugas Utama */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6, ease: "easeOut" }}
          className="relative w-full lg:w-sm h-auto lg:h-64"
        >
          <div className="md:flex hidden absolute top-0 right-0 z-10 w-10 h-10 md:w-12.5 md:h-12.5 bg-[#00509E] border-2 md:border-3 border-[#003C7D] rounded-bl-[10px] items-center justify-center">
            <span className="font-poppins font-semibold text-sm md:text-xl text-white leading-none">
              3
            </span>
          </div>

          <div className="w-full h-full bg-[#FFC107] border-2 md:border-3 border-[#9F6E0E] md:rounded-md rounded-sm px-5 md:px-8.5 py-4 md:py-9 flex items-center">
            <div className="flex flex-col gap-2.5">
              <motion.h3
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.8, ease: "easeOut" }}
                className="font-poppins font-bold text-xl md:text-2xl leading-normal text-[#1A1A1A]"
              >
                Tugas Utama
              </motion.h3>
              <motion.ul
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.9, ease: "easeOut" }}
                className="font-plus-jakarta font-medium md:text-sm text-xs leading-[1.26] text-[#1A1A1A] list-disc list-inside space-y-1 md:text-left text-justify"
              >
                {tugasUtama.slice(0, 4).map((item, index) => (
                  <li key={index} className="list-none">
                    {item}
                  </li>
                ))}
              </motion.ul>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default SekbidInfoCards;
