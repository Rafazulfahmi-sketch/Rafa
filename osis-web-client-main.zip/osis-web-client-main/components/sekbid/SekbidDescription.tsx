"use client";

import React from "react";
import { motion } from "motion/react";

interface SekbidDescriptionProps {
  title: string;
  description: string;
}

const SekbidDescription = ({ title, description }: SekbidDescriptionProps) => {
  return (
    <div className="w-full py-4 md:py-6">
      <div className="flex flex-col gap-2">
        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
          className="font-poppins font-bold text-lg md:text-3xl leading-normal uppercase text-black"
        >
          {title}
        </motion.h1>
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6, ease: "easeOut" }}
          className="font-plus-jakarta font-normal text-sm md:text-base leading-[1.26] text-black"
        >
          {description}
        </motion.p>
      </div>
    </div>
  );
};

export default SekbidDescription;
