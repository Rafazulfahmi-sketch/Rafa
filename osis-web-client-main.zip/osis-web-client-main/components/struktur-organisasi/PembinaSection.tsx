"use client";

import Image from "next/image";
import React from "react";
import { motion } from "motion/react";

import { useActiveAdvisors } from "@/hooks/useApi";

const PembinaSection: React.FC = () => {
  const { data: advisors, loading } = useActiveAdvisors();

  if (loading && advisors.length === 0) return null;

  return (
    <section className="flex flex-col items-center gap-10 px-4 md:px-16">
      {advisors.map((advisor, index) => (
        <motion.div
          key={advisor.id}
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{
            duration: 0.6,
            delay: 0.4,
            ease: "easeOut",
          }}
          className="bg-[#00509E] w-full max-w-5xl border-2 border-[#003C77] rounded-[10px] p-6 md:p-10 flex flex-col md:flex-row items-start gap-8 md:gap-8"
        >
          <div className="flex flex-col gap-4 md:gap-8 flex-1">
            <div className="flex flex-col text-left">
              <motion.h2
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.2,
                  delay: 0.7,
                  ease: "easeOut",
                }}
                className="font-poppins font-semibold text-xl md:text-2xl leading-normal text-white"
              >
                Dewan Pembina
              </motion.h2>
              <motion.p
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.2,
                  delay: 0.9,
                  ease: "easeOut",
                }}
                className="font-jakarta font-medium text-sm md:text-base leading-[1.5em] text-white"
              >
                Informasi profil Pembina OSIS &amp; MPPK
              </motion.p>
            </div>
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.2,
                delay: 1.1,
                ease: "easeOut",
              }}
              className="md:block hidden font-jakarta font-medium text-[14px] md:text-[16px] leading-[1.8em] text-white"
            >
              <p>Nama: {advisor.name}</p>
              <p>Jabatan: Pembina OSIS MPPK Periode 2025/2026</p>
              <p>Pesan: &quot;{advisor.message}&quot;</p>
              <p>Lahir: {advisor.born_date}</p>
            </motion.div>
          </div>
          <div className="space-y-5">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.2,
                delay: 1.3,
                ease: "easeOut",
              }}
              className="relative w-full border-b-2 border-white h-60 md:w-90 md:h-90 shrink-0"
            >
              <Image
                src={advisor.image || "/assets/struktur-organisasi/pembina-photo-20e49e.png"}
                alt={`${advisor.name} - Pembina OSIS`}
                fill
                className="object-contain absolute bottom-0"
                style={{
                  filter: "drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25))",
                }}
              />
            </motion.div>
            <div className="block md:hidden font-jakarta font-medium text-sm md:text-base leading-6 text-white">
              <p>Nama: {advisor.name}</p>
              <p>Jabatan: Pembina OSIS MPPK Periode 2025/2026</p>
              <p>Pesan: &quot;{advisor.message}&quot;</p>
              <p>Lahir: {advisor.born_date}</p>
            </div>
          </div>
        </motion.div>
      ))}
    </section>
  );
};

export default PembinaSection;
