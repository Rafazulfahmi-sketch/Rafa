"use client";

import Image from "next/image";
import React from "react";
import { motion } from "motion/react";

import { useStructureHeroes } from "@/hooks/useApi";

const HeroSection: React.FC = () => {
  const { data: heroes } = useStructureHeroes();
  
  // Try to find a hero that matches "Struktur" or just pick first
  const hero = heroes[0];

  return (
    <section className="relative w-full h-fit md:h-109 overflow-hidden">
      <Image
        src="/assets/struktur-organisasi/hero-background.png"
        alt="Background"
        fill
        className="object-cover hidden md:block"
        priority
      />
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        whileInView={{ y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{
          duration: 0.6,
          delay: 0.4,
          ease: "easeOut",
        }}
        className="absolute right-0 top-15 w-155 h-94 hidden lg:block"
      >
        <Image
          src={hero?.image || "/assets/struktur-organisasi/hero-trimitra-313e17.png"}
          alt="Trimitra OSIS MILLENIUM"
          fill
          className="object-contain"
        />
      </motion.div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        whileInView={{ y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{
          duration: 0.4,
          delay: 0.2,
          ease: "easeOut",
        }}
        className="md:absolute left-16 py-10 px-5 container text-black md:text-white bottom-20 flex flex-col max-w-185"
      >
        <h1 className="font-poppins font-black text-2xl md:text-3xl leading-[1.5em] uppercase">
          {hero?.title || "Struktur Kepengurusan"}
        </h1>
        <h2 className="font-jakarta font-semibold text-sm md:text-3xl leading-[1.26em] uppercasw">
          OSIS MILLENIUM PERIODE 2025/2026
        </h2>
      </motion.div>
    </section>
  );
};

export default HeroSection;
