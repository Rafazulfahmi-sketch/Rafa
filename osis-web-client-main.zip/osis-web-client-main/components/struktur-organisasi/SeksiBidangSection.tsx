"use client";

import Image from "next/image";
import React, { useRef } from "react";
import { Button } from "../ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { motion } from "motion/react";
import Link from "next/link";

const cards = [
  {
    src: "/assets/struktur-organisasi/sekbid-card-1.png",
    alt: "Seksi Bidang 1",
  },
  {
    src: "/assets/struktur-organisasi/sekbid-card-2.png",
    alt: "Seksi Bidang 2",
  },
  {
    src: "/assets/struktur-organisasi/sekbid-card-3.png",
    alt: "Seksi Bidang 3",
  },
  {
    src: "/assets/struktur-organisasi/sekbid-card-4.png",
    alt: "Seksi Bidang 4",
  },
];

import { useActiveDepartments } from "@/hooks/useApi";
import { getImageUrl } from "@/lib/utils";

const SeksiBidangSection: React.FC = () => {
  const { data: departments, loading } = useActiveDepartments();
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 310;
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      });
    }
  };

  if (loading && departments.length === 0) return null;

  return (
    <section className="container mx-auto px-4 md:px-16">
      <div className="flex flex-col gap-6 md:gap-8">
        <div className="flex flex-col max-w-full">
          <motion.h2
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.6,
              delay: 0.2,
              ease: "easeOut",
            }}
            className="font-poppins font-semibold text-xl md:text-3xl leading-[1.5em] uppercase text-black"
          >
            Seksi Bidang
          </motion.h2>
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.6,
              delay: 0.4,
              ease: "easeOut",
            }}
            className="font-jakarta font-medium text-xs md:text-base leading-[1.5em] text-black"
          >
            Mengoordinasikan dan Mengembangkan Potensi Siswa di Berbagai Bidang
          </motion.p>
        </div>
        <div
          ref={scrollRef}
          className="w-full overflow-x-auto scroll-smooth"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          <div className="flex gap-3 w-max">
            {departments.map((dept, index) => (
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.4,
                  delay: 0.0 + (index + 1) * 0.1,
                  ease: "easeOut",
                }}
                key={dept.id}
                className="relative w-70 h-43 md:w-108 md:h-66.5 rounded-md shadow-xl overflow-hidden shrink-0"
              >
                <Link href={`/pengurus-osis/${dept.id}`}>
                  <Image
                    src={
                      dept.thumbnail ||
                      "/assets/struktur-organisasi/sekbid-placeholder.png"
                    }
                    alt={dept.name}
                    fill
                    className="object-cover"
                  />
                  <p className="absolute bottom-0 left-0 bg-black/50 p-2 pr-5 text-white font-semibold text-sm">
                    {dept.name}
                  </p>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
        <div className="md:flex hidden items-center gap-2 self-end">
          <Button
            size={"icon"}
            onClick={() => scroll("left")}
            className="w-8 h-8 bg-[#00509E] hover:bg-[#003C77] transition-colors cursor-pointer"
            aria-label="Previous"
          >
            <ChevronLeft />
          </Button>
          <Button
            size={"icon"}
            onClick={() => scroll("right")}
            className="w-8 h-8 bg-[#00509E] hover:bg-[#003C77] transition-colors cursor-pointer"
            aria-label="Next"
          >
            <ChevronRight />
          </Button>
        </div>
        <p className="w-fit text-primary text-[10px] font-medium font-poppins md:hidden block">
          Geser untuk lihat lebih banyak!
        </p>
      </div>
    </section>
  );
};

export default SeksiBidangSection;
