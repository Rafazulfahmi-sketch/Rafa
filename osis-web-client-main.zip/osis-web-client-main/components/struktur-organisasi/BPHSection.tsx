"use client";

import Image from "next/image";
import React from "react";
import { motion } from "motion/react";
import Link from "next/link";

import { useActiveDepartments } from "@/hooks/useApi";
import { getImageUrl } from "@/lib/utils";

const BPHSection: React.FC = () => {
  const { data: departments, loading } = useActiveDepartments();

  const bphNames = ["Trimitra", "Sekretaris", "Bendahara"];

  const bphData = departments
    .filter((dept) => bphNames.includes(dept.name))
    .sort((a, b) => bphNames.indexOf(a.name) - bphNames.indexOf(b.name));

  if (loading && bphData.length === 0) return null;

  return (
    <section className="container mx-auto px-4 md:px-16">
      <div className="flex flex-col items-center gap-6 md:gap-8">
        <div className="flex flex-col items-center justify-center text-center">
          <motion.h2
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.6,
              delay: 0.2,
              ease: "easeOut",
            }}
            className="font-poppins font-semibold text-xl md:text-2xl leading-[1.5em] uppercase text-black"
          >
            Badan Pengurus Harian
          </motion.h2>
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.6,
              delay: 0.4,
              ease: "easeOut",
            }}
            className="font-jakarta font-medium text-sm md:text-base leading-[1.5em] text-black"
          >
            Mengawasi dan Mengoordinasikan Seluruh Seksi Bidang
          </motion.p>
        </div>
        <div className="flex flex-col md:flex-row gap-3 w-full">
          {bphData.map((dept, index) => (
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.6,
                delay: 0.0 + (index + 1) * 0.3,
                ease: "easeOut",
              }}
              key={dept.id}
              className="relative w-full hover:scale-105 cursor-pointer duration-150 transition-transform md:w-1/3 shadow-xl aspect-video rounded-sm overflow-hidden"
            >
              <Link href={`/pengurus-osis/${dept.id}`}>
                <Image
                  src={
                    dept.thumbnail ||
                    "/assets/struktur-organisasi/sekbid-placeholder.png"
                  }
                  alt={dept.name}
                  fill
                  className="object-cover"
                />
                <p className="absolute bottom-0 left-0 bg-black/50 p-2 pr-5 text-white font-semibold text-sm">
                  {dept.name}
                </p>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BPHSection;
