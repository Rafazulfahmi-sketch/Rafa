"use client";

import Image from "next/image";
import React from "react";
import { motion } from "motion/react";
import { CustomDialog } from "../fragments/DetailDialog";
import { getImageUrl } from "@/lib/utils";

import { Achievement } from "@/hooks/useApi";

interface PrestasiGridProps {
  data: Achievement[];
  loading?: boolean;
}

const PrestasiGrid = ({ data, loading }: PrestasiGridProps) => {
  if (loading && data.length === 0) return <div>Loading...</div>;
  if (!loading && data.length === 0) return <div className="text-center py-10">Belum ada data prestasi.</div>;

  const formattedData = data.map(a => ({
    image: getImageUrl(a.thumbnail, "/assets/home/achievements/achievement-1.png"),
    name: a.title,
    detail: a.description,
    achiever: a.participant,
    date: new Date(a.date),
  }));

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-4 mb-12 md:mb-16">
      {formattedData.map((achievement, index) => (
        <CustomDialog data={achievement} key={index}>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            transition={{
              duration: 1,
              delay: 0.0 + (index + 1) * 0.1,
              ease: "easeOut",
            }}
            key={index}
            className="group relative aspect-video w-full overflow-hidden cursor-pointer md:rounded-sm md:hover:scale-105 duration-100 md:transition-transform rounded-md shadow-sm hover:shadow-md transition-shadow duration-300"
          >
            <Image
              src={achievement.image}
              alt={achievement.name + " " + index + 1}
              fill
              className="object-cover"
            />
            <p className="absolute bottom-0 left-0 bg-black/50 p-2 pr-5 text-white font-semibold text-sm">
              {achievement.name}
            </p>
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
          </motion.div>
        </CustomDialog>
      ))}
    </div>
  );
};

export default PrestasiGrid;
