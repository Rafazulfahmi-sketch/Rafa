import React from "react";

const PrestasiHeader = () => {
  return (
    <div className="w-full text-left mb-10 md:mb-12">
      <h1 className="font-poppins font-semibold text-xl md:text-4xl lg:text-[40px] leading-tight text-black mb-2 md:mb-1 uppercase drop-shadow-sm">
        PEROLEHAN PRESTASI MURID SMKN 1 CIBINONG
      </h1>
      <p className="font-poppins font-normal text-sm md:text-base md:leading-relaxed text-black/80 max-w-4xl">
        Prestasi gemilang siswa dalam berbagai kompetisi dan bidang.
      </p>
    </div>
  );
};

export default PrestasiHeader;
