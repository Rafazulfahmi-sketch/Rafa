import React from 'react';
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from 'lucide-react';

const PrestasiPagination = () => {
    return (
        <div className="flex justify-center items-center pb-8 md:pb-0">
            <div className="flex items-center gap-3">
                 {/* Match design: Square buttons, outlined by default, filled for arrows/active? 
                     Design shows: 
                     < [1] [2] [3] ... > (Blue filled blocks? or outlines?)
                     Zooming in on Figma (mental check): Often these are outlined squares with blue text, 
                     or blue squares with white text.
                     Let's go with a clean, high-contrast look based on the blue theme.
                 */}
                  
                  {/* Previous Button - Blue Background */}
                  <Button 
                    className="h-10 w-10 p-0 rounded-md bg-[#00509E] hover:bg-[#003c77] text-white transition-all shadow-sm"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                  
                  {/* Page 1 - White Background, Blue Border/Text */}
                  <Button 
                    className="h-10 w-10 p-0 rounded-md bg-white border border-[#00509E] text-[#00509E] hover:bg-[#f0f9ff] transition-all shadow-sm font-semibold"
                  >
                    1
                  </Button>

                  {/* Page 2 - White Background, Blue Border/Text */}
                  <Button 
                    className="h-10 w-10 p-0 rounded-md bg-white border border-[#00509E] text-[#00509E] hover:bg-[#f0f9ff] transition-all shadow-sm font-semibold"
                  >
                    2
                  </Button>

                  {/* Page 3 - White Background, Blue Border/Text */}
                  <Button 
                    className="h-10 w-10 p-0 rounded-md bg-white border border-[#00509E] text-[#00509E] hover:bg-[#f0f9ff] transition-all shadow-sm font-semibold"
                  >
                    3
                  </Button>
                  
                  <span className="flex items-center justify-center w-10 h-10 border border-[#00509E] rounded-md font-bold text-[#00509E] tracking-widest">
                    ..
                  </span>
                  
                  {/* Next Button - Blue Background */}
                  <Button 
                    className="h-10 w-10 p-0 rounded-md bg-[#00509E] hover:bg-[#003c77] text-white transition-all shadow-sm"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </Button>
            </div>
        </div>
    );
};

export default PrestasiPagination;
