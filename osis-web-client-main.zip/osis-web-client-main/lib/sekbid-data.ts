export interface SekbidMember {
    name: string;
    role: string;
    photo: string;
}

export interface SekbidData {
    id: number;
    title: string;
    description: string;
    heroImage: string;
    programKerja: {
        images: string[];
    };
    members: SekbidMember[];
    groupPhoto: string;
    tujuan: string[];
    logo: {
        image: string;
        description: string;
    };
    tugasUtama: string[];
}

const sekbidData: Record<string, SekbidData> = {
    "1": {
        id: 1,
        title: "Ketaqwaan Terhadap Tuhan Yang Maha Esa",
        description: "Seksi Bidang 1 berfokus pada pembinaan ketaqwaan siswa terhadap Tuhan Yang Maha Esa melalui kegiatan keagamaan dan peringatan hari besar keagamaan. Sekbid ini berperan aktif dalam meningkatkan keimanan dan ketaqwaan seluruh warga sekolah.",
        heroImage: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        programKerja: {
            images: [
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
            ],
        },
        members: [
            { name: "Ahmad Fauzi", role: "Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Siti Nurhaliza", role: "Partner Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Rizky Pratama", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Dewi Safitri", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Budi Santoso", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
        ],
        groupPhoto: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        tujuan: [
            "Meningkatkan keimanan dan ketaqwaan siswa.",
            "Menyelenggarakan kegiatan keagamaan secara rutin.",
            "Memperingati hari besar keagamaan di lingkungan sekolah.",
        ],
        logo: {
            image: "/assets/perolehan-prestasi/perolehan-prestasi.png",
            description: "Logo Sekbid 1 melambangkan ketaqwaan dan keimanan sebagai fondasi utama dalam kehidupan bermasyarakat dan pendidikan di sekolah.",
        },
        tugasUtama: [
            "Pengurus melaksanakan ketentuan dan kebijakan sesuai dengan Anggaran Dasar dan Anggaran Rumah Tangga (AD/ART), hasil sidang pleno serta kebijakan organisasi yang lain.",
            "Menyampaikan pertanggungjawaban kepengurusan OSIS selama 1 (satu) periode masa jabatannya.",
            "Menjalankan program kerja yang telah ditetapkan.",
        ],
    },
    "2": {
        id: 2,
        title: "Kehidupan Berbangsa dan Bernegara",
        description: "Seksi Bidang 2 berfokus pada pembinaan kehidupan berbangsa dan bernegara melalui upacara bendera, peringatan hari nasional, dan kegiatan bela negara. Sekbid ini berperan aktif dalam menumbuhkan jiwa nasionalisme dan patriotisme siswa.",
        heroImage: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        programKerja: {
            images: [
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
            ],
        },
        members: [
            { name: "Reza Firmansyah", role: "Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Anisa Putri", role: "Partner Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Dimas Arya", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Layla Azzahra", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Farhan Hakim", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
        ],
        groupPhoto: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        tujuan: [
            "Menumbuhkan jiwa nasionalisme dan patriotisme.",
            "Menyelenggarakan upacara bendera dengan tertib.",
            "Memperingati hari-hari nasional di lingkungan sekolah.",
        ],
        logo: {
            image: "/assets/perolehan-prestasi/perolehan-prestasi.png",
            description: "Logo Sekbid 2 melambangkan semangat kebangsaan dan cinta tanah air yang menjadi fondasi kehidupan bermasyarakat dan bernegara.",
        },
        tugasUtama: [
            "Pengurus melaksanakan ketentuan dan kebijakan sesuai dengan Anggaran Dasar dan Anggaran Rumah Tangga (AD/ART), hasil sidang pleno serta kebijakan organisasi yang lain.",
            "Menyampaikan pertanggungjawaban kepengurusan OSIS selama 1 (satu) periode masa jabatannya.",
            "Menjalankan program kerja yang telah ditetapkan.",
        ],
    },
    "3": {
        id: 3,
        title: "Pendidikan Pendahuluan Bela Negara",
        description: "Seksi Bidang 3 berfokus pada pendidikan pendahuluan bela negara melalui kegiatan pramuka, PBB, dan pelatihan kepemimpinan. Sekbid ini berperan aktif dalam membentuk karakter disiplin dan tanggung jawab siswa.",
        heroImage: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        programKerja: {
            images: [
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
            ],
        },
        members: [
            { name: "Aldi Nugroho", role: "Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Maya Indah", role: "Partner Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Rahmat Hidayat", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Nadia Permata", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Ilham Saputra", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
        ],
        groupPhoto: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        tujuan: [
            "Membentuk karakter disiplin dan tanggung jawab.",
            "Menyelenggarakan latihan kepemimpinan dan bela negara.",
            "Mengembangkan kemampuan pramuka siswa.",
        ],
        logo: {
            image: "/assets/perolehan-prestasi/perolehan-prestasi.png",
            description: "Logo Sekbid 3 melambangkan semangat bela negara dan kedisiplinan sebagai pondasi karakter generasi muda yang tangguh.",
        },
        tugasUtama: [
            "Pengurus melaksanakan ketentuan dan kebijakan sesuai dengan Anggaran Dasar dan Anggaran Rumah Tangga (AD/ART), hasil sidang pleno serta kebijakan organisasi yang lain.",
            "Menyampaikan pertanggungjawaban kepengurusan OSIS selama 1 (satu) periode masa jabatannya.",
            "Menjalankan program kerja yang telah ditetapkan.",
        ],
    },
    "4": {
        id: 4,
        title: "Kepribadian dan Budi Pekerti Luhur",
        description: "Seksi Bidang 4 berfokus pada pembinaan kepribadian dan budi pekerti luhur melalui kegiatan literasi, diskusi moral, dan pengembangan karakter. Sekbid ini berperan aktif dalam membentuk pribadi siswa yang berakhlak mulia.",
        heroImage: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        programKerja: {
            images: [
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
            ],
        },
        members: [
            { name: "Fajar Ramadhan", role: "Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Citra Lestari", role: "Partner Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Galih Permana", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Putri Ayu", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Hendra Wijaya", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
        ],
        groupPhoto: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        tujuan: [
            "Membentuk pribadi siswa yang berakhlak mulia.",
            "Meningkatkan literasi dan wawasan siswa.",
            "Menyelenggarakan kegiatan pengembangan karakter.",
        ],
        logo: {
            image: "/assets/perolehan-prestasi/perolehan-prestasi.png",
            description: "Logo Sekbid 4 melambangkan kepribadian luhur dan budi pekerti sebagai cerminan karakter bangsa Indonesia yang beradab.",
        },
        tugasUtama: [
            "Pengurus melaksanakan ketentuan dan kebijakan sesuai dengan Anggaran Dasar dan Anggaran Rumah Tangga (AD/ART), hasil sidang pleno serta kebijakan organisasi yang lain.",
            "Menyampaikan pertanggungjawaban kepengurusan OSIS selama 1 (satu) periode masa jabatannya.",
            "Menjalankan program kerja yang telah ditetapkan.",
        ],
    },
    "5": {
        id: 5,
        title: "Berorganisasi, Pendidikan Politik dan Kepemimpinan",
        description: "Seksi Bidang 5 berfokus pada pembinaan berorganisasi, pendidikan politik, dan kepemimpinan melalui kegiatan LDKS, diskusi, dan simulasi. Sekbid ini berperan aktif dalam mengembangkan jiwa kepemimpinan siswa.",
        heroImage: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        programKerja: {
            images: [
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
            ],
        },
        members: [
            { name: "Yusuf Maulana", role: "Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Rina Amelia", role: "Partner Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Bagas Aditya", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Karina Dewi", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Eko Prasetyo", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
        ],
        groupPhoto: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        tujuan: [
            "Mengembangkan jiwa kepemimpinan siswa.",
            "Menyelenggarakan latihan dasar kepemimpinan siswa (LDKS).",
            "Meningkatkan pemahaman politik dan demokrasi.",
        ],
        logo: {
            image: "/assets/perolehan-prestasi/perolehan-prestasi.png",
            description: "Logo Sekbid 5 melambangkan semangat kepemimpinan dan berorganisasi sebagai bekal generasi muda dalam bermasyarakat.",
        },
        tugasUtama: [
            "Pengurus melaksanakan ketentuan dan kebijakan sesuai dengan Anggaran Dasar dan Anggaran Rumah Tangga (AD/ART), hasil sidang pleno serta kebijakan organisasi yang lain.",
            "Menyampaikan pertanggungjawaban kepengurusan OSIS selama 1 (satu) periode masa jabatannya.",
            "Menjalankan program kerja yang telah ditetapkan.",
        ],
    },
    "6": {
        id: 6,
        title: "Keterampilan dan Kewirausahaan",
        description: "Seksi Bidang 6 berfokus pada pembinaan keterampilan dan kewirausahaan melalui pelatihan, bazar, dan pengembangan produk kreatif. Sekbid ini berperan aktif dalam mendorong kreativitas dan jiwa wirausaha siswa.",
        heroImage: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        programKerja: {
            images: [
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
            ],
        },
        members: [
            { name: "Arief Wicaksono", role: "Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Dina Rahmawati", role: "Partner Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Surya Darma", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Fitri Handayani", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Joko Supriyadi", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
        ],
        groupPhoto: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        tujuan: [
            "Mendorong kreativitas dan jiwa wirausaha siswa.",
            "Menyelenggarakan pelatihan keterampilan dan bazar.",
            "Mengembangkan produk kreatif siswa.",
        ],
        logo: {
            image: "/assets/perolehan-prestasi/perolehan-prestasi.png",
            description: "Logo Sekbid 6 melambangkan kreativitas dan kewirausahaan sebagai bekal siswa dalam menghadapi dunia kerja dan usaha.",
        },
        tugasUtama: [
            "Pengurus melaksanakan ketentuan dan kebijakan sesuai dengan Anggaran Dasar dan Anggaran Rumah Tangga (AD/ART), hasil sidang pleno serta kebijakan organisasi yang lain.",
            "Menyampaikan pertanggungjawaban kepengurusan OSIS selama 1 (satu) periode masa jabatannya.",
            "Menjalankan program kerja yang telah ditetapkan.",
        ],
    },
    "7": {
        id: 7,
        title: "Pembinaan Kualitas Jasmani, Kesehatan Gizi berbasis Sumber Gizi yang ter-verifikasi",
        description: "Seksi Bidang 7 berfokus pada pembinaan kualitas jasmani, kesehatan, dan gizi siswa melalui penerapan pola hidup bersih dan sehat berbasis sumber gizi yang terverifikasi. Sekbid ini berperan aktif dalam meningkatkan kesadaran hidup sehat, menjaga kebersihan serta keasrian lingkungan sekolah. Melalui kampanye hidup bersih dan sehat, Sekbid 7 mendukung terciptanya lingkungan sekolah yang nyaman, sehat, dan berkelanjutan.",
        heroImage: "/assets/sekbid/hero-sekbid-7.png",
        programKerja: {
            images: [
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
                "/assets/perolehan-prestasi/perolehan-prestasi.png",
            ],
        },
        members: [
            { name: "Marwah Lutfiah", role: "Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Bilal Habsyi Ramdani", role: "Partner Koordinator", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Khayra Natasya D. P. I", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "M. Apriansyah Alwan", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
            { name: "Putri Khania Zahra", role: "Anggota", photo: "/assets/perolehan-prestasi/perolehan-prestasi.png" },
        ],
        groupPhoto: "/assets/perolehan-prestasi/perolehan-prestasi.png",
        tujuan: [
            "Penyadaran pola hidup sehat terhadap murid.",
            "Mensosialisasikan pola hidup bersih dan sehat.",
            "Melaksanakan program kerja OSIS yang berkaitan dengan kesehatan jasmani, lingkungan, dan pengelolaan gizi di sekolah.",
        ],
        logo: {
            image: "/assets/perolehan-prestasi/perolehan-prestasi.png",
            description: "Hygcia (dewi kebersihan) merupakan anak perempuan dari Aesculapius disebut sebagai dewa penyembuhan dalam mitologi Yunani. Aesculapius sendiri memiliki tongkat yang dijadikan sebagai simbol kedokteran.",
        },
        tugasUtama: [
            "Pengurus melaksanakan ketentuan dan kebijakan sesuai dengan Anggaran Dasar dan Anggaran Rumah Tangga (AD/ART), hasil sidang pleno serta kebijakan organisasi yang lain.",
            "Menyampaikan pertanggungjawaban kepengurusan OSIS selama 1 (satu) periode masa jabatannya.",
            "Menjalankan program kerja yang telah ditetapkan.",
        ],
    },
};

export function getSekbidData(id: string): SekbidData | undefined {
    return sekbidData[id];
}

export function getAllSekbidIds(): string[] {
    return Object.keys(sekbidData);
}
