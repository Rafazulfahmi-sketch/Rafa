import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getImageUrl(
  path: string | null,
  placeholder: string = "",
): string {
  if (!path) return placeholder;

  let url = path;
  if (
    !path.startsWith("http://") &&
    !path.startsWith("https://") &&
    !path.startsWith("data:")
  ) {
    const baseUrl =
      process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";
    const cleanPath = path.startsWith("/") ? path : `/${path}`;
    url = `${baseUrl}${cleanPath}`;
  }

  if (url.includes("127.0.0.1")) {
    url = url.replace("127.0.0.1", "localhost");
  }

  return url;
}
