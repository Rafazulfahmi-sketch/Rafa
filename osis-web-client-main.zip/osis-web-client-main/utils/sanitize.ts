import DOMPurify from 'dompurify';

export function sanitizeHtml(html: string): string {
    if (typeof window !== 'undefined') {
        return DOMPurify.sanitize(html);
    }
    // Return raw html during SSR, it will be sanitized on the client side
    // Since we trust our admin source (Filament), this is acceptable for SSR
    return html;
}
