# Agent Guidelines & Best Practices
**Project:** `osis-web-client` (Frontend)

This document serves as the single source of truth for the AI Agent working on this project. Adherence to these rules is mandatory to ensure code quality, consistency, and safety.

## 1. Core Principles (The Golden Rules)

*   **NO Hallucinations**: Do not invent properties, methods, or imports that do not exist. Verify before writing.
*   **Ask Before Executing**: Always clarify ambiguous requirements or potentially destructive actions before execution.
*   **Clean Code & DRY**: Write clean, readable code. Avoid redundancy. Refactor if you see duplicate logic.
*   **Structure & Tidy**: Keep the project structure organized. Do not leave unused files or spaghetti code.
*   **Frontend Focus**: You are a Frontend Specialist. Do not touch backend logic unless explicitly instructed (project is currently frontend-only).

## 2. Tech Stack Requirements

*   **Framework**: Next.js 16 (App Router)
*   **Library**: React 19
*   **Styling**: Tailwind CSS 4
*   **Components**: Shadcn UI (Radix Primitives)
*   **Language**: TypeScript (Strict Mode)

## 3. Coding Standards & Best Practices

### A. TypeScript Enforcement
*   **Strict Types**: Explicitly define interfaces or types for all props and state.
*   **No `any`**: use of `any` is strictly prohibited unless absolutely necessary (must include valid `// TODO` comment explaining why).

### B. Component Structure
*   **Functional Components**: ALWAYS use **Arrow Functions**.
    ```tsx
    // ✅ Correct
    const MyComponent: React.FC<Props> = ({ data }) => { ... }

    // ❌ Incorrect
    function MyComponent({ data }: Props) { ... }
    ```
*   **Colocation**: Keep related styles, sub-components, or hooks in the same directory if they are specific to a feature.
*   **Early Return**: Use guard clauses to handle loading/error states at the top of the component to avoid deep nesting.

### C. Naming Conventions
*   **Components/Files**: `PascalCase` (e.g., `UserProfile.tsx`, `ButtonPrimary.tsx`).
*   **Functions/Variables**: `camelCase` (e.g., `handleSubmit`, `isValid`).
*   **Folders**: `kebab-case` (e.g., `components/user-profile`, `app/pengurus-osis`).

### D. Styling (Tailwind CSS)
*   **Components First**: Use Shadcn components (`components/ui`) whenever possible.
*   **Utility Usage**: Use the `cn()` utility for conditional class merging.
    ```tsx
    // ✅ Correct
    <div className={cn("bg-white p-4", isActive && "bg-blue-500")} />
    ```
*   **Avoid Arbitrary Values**: Avoid using arbitrary values like `w-[123px]` unless strictly necessary for design fidelity. Use proper theme tokens.

### E. Import Organization
Organize imports in the following order:
1.  **External Libraries** (React, Next.js, lucide-react, etc.)
2.  **Absolute Imports** (`@/components/...`, `@/lib/...`)
3.  **Relative Imports** (`./utils`, `../types`)

## 4. Workflow
1.  **Analyze**: Understand the file/folder structure before acting.
2.  **Confirm**: Ask the user if requirements are vague.
3.  **Implement**: Write code following the standards above.
4.  **Verify**: Ensure no lint errors and code actually works.
