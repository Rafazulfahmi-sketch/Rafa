import type { Metadata } from "next";
import "./globals.css";
import { inter, montserrat, plusJakartaSans, poppins } from "@/lib/fonts";
import Navbar from "@/components/fragments/Navbar";
import Footer from "@/components/fragments/Footer";

export const metadata: Metadata = {
  title: {
    template: "%s | OSIS SMKN 1 Cibinong",
    default: "OSIS SMKN 1 Cibinong",
  },
  description: "Website resmi Organisasi Siswa Intra Sekolah (OSIS) SMKN 1 Cibinong. Temukan informasi terbaru seputar kegiatan, program kerja, dan prestasi siswa.",
  keywords: ["OSIS", "SMKN 1 Cibinong", "Siswa", "Pendidikan", "Organisasi Siswa", "Prestasi", "Sekolah", "Bogor"],
  authors: [{ name: "OSIS SMKN 1 Cibinong" }],
  openGraph: {
    title: "OSIS SMKN 1 Cibinong",
    description: "Website resmi Organisasi Siswa Intra Sekolah (OSIS) SMKN 1 Cibinong.",
    url: "https://osissmkn1cibinong.com",
    siteName: "OSIS SMKN 1 Cibinong",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        suppressHydrationWarning
        className={`${inter.variable} ${plusJakartaSans.variable} ${poppins.variable} ${montserrat.variable} antialiased`}
      >
        <Navbar />
        <div className="bg-[linear-gradient(to_right,#0206181e,transparent_1px),linear-gradient(to_bottom,#0206181e,transparent_1px)] bg-size-[40px_40px]">
          {children}
        </div>
        <Footer />
      </body>
    </html>
  );
}
