import type { Metadata } from "next";
import PerolehanPrestasiLayout from "@/components/layouts/PerolehanPrestasiLayout";

export const metadata: Metadata = {
  title: "Perolehan Prestasi",
  description: "Jelajahi berbagai prestasi membanggakan yang diraih oleh siswa-siswi SMKN 1 Cibinong dalam berbagai bidang.",
  keywords: ["Prestasi Siswa", "Kejuaraan", "Lomba", "SMKN 1 Cibinong", "Kebanggaan"],
};
const page = () => {
  return <PerolehanPrestasiLayout />;
};

export default page;
