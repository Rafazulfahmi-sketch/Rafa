import type { Metadata } from "next";
import HomeLayout from "@/components/layouts/HomeLayout";

export const metadata: Metadata = {
  title: "Beranda",
  description: "Selamat datang di website resmi OSIS SMKN 1 Cibinong. Cerdas, Kreatif, dan Inovatif.",
  keywords: ["Beranda OSIS", "OSIS SMKN 1 Cibinong", "Kegiatan Sekolah", "Bogor"],
};
export default function page() {
  return <HomeLayout />;
}
