import { Loader2 } from "lucide-react";
import Image from "next/image";

export default function Loading() {
  return (
    <main className="min-h-screen flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="relative w-24 h-24">
          {/* Nanti tinggal aktifkan ini kalau sudah ada GIF */}
          {/*
          <Image
            src="/assets/loading.gif"
            alt="Loading..."
            fill
            className="object-contain"
            unoptimized
          />
          */}

          {/* Loader sementara pakai Lucide */}
          <Loader2 className="animate-spin text-primary w-full h-full" />
        </div>

        <p className="font-poppins font-medium text-primary animate-pulse">
          Loading OSIS Millenium...
        </p>
      </div>
    </main>
  );
}
