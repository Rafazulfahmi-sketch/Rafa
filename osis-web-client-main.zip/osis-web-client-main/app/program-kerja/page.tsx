import type { Metadata } from "next";
import ProgramKerjaLayout from "@/components/layouts/ProgramKerjaLayout";

export const metadata: Metadata = {
  title: "Program Kerja",
  description: "Daftar program kerja OSIS SMKN 1 Cibinong yang bertujuan untuk mengembangkan minat, bakat, dan prestasi siswa.",
  keywords: ["Program Kerja", "Kegiatan OSIS", "SMKN 1 Cibinong", "Event Sekolah"],
};
const page = () => {
  return <ProgramKerjaLayout />;
};

export default page;