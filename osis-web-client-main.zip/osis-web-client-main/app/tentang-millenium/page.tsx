import type { Metadata } from "next";
import TentangMilleniumLayout from "@/components/layouts/TentangMilleniumLayout";

export const metadata: Metadata = {
  title: "Tentang Millenium",
  description: "Kenali lebih jauh tentang OSIS Millenium SMKN 1 Cibinong, sejarah, visi misi, dan semangat kami.",
  keywords: ["Tentang Kami", "OSIS Millenium", "Sejarah", "Visi Misi", "SMKN 1 Cibinong"],
};
const page = () => {
  return (
   <TentangMilleniumLayout />
  );
};

export default page;