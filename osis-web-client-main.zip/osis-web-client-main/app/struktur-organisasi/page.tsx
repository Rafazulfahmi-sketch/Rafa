import type { Metadata } from "next";
import StrukturOrganisasiLayout from "@/components/layouts/StrukturOrganisasiLayout";

export const metadata: Metadata = {
  title: "Struktur Organisasi",
  description: "Lihat susunan kepengurusan dan struktur organisasi OSIS SMKN 1 Cibinong periode ini.",
  keywords: ["Struktur Organisasi", "Pengurus OSIS", "Seksi Bidang", "SMKN 1 Cibinong"],
};
const page = () => {
  return <StrukturOrganisasiLayout />;
};

export default page;
