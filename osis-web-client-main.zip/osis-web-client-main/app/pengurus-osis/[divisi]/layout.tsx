import type { Metadata } from "next";
import { getSekbidData } from "@/lib/sekbid-data";

type Props = {
  params: Promise<{ divisi: string }>;
};

export async function generateMetadata(
  { params }: Props
): Promise<Metadata> {
  const resolvedParams = await params;
  const divisiId = resolvedParams.divisi;
  const mockData = getSekbidData(divisiId);
  const title = mockData?.title || `Divisi ${divisiId}`;
  
  return {
    title: title,
    description: `Halaman detail kepengurusan dan program kerja dari ${title} di OSIS SMKN 1 Cibinong.`,
    keywords: ["Seksi Bidang", title, "Divisi OSIS", "Pengurus OSIS", "SMKN 1 Cibinong", "Program Kerja"],
  };
}

export default function Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
