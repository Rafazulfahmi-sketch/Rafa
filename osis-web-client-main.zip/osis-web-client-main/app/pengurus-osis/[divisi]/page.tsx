"use client";

import { use, useEffect, useState } from "react";
import { notFound } from "next/navigation";
import { getSekbidData } from "@/lib/sekbid-data";
import SekbidHero from "@/components/sekbid/SekbidHero";
import SekbidDescription from "@/components/sekbid/SekbidDescription";
import SekbidProgramKerja from "@/components/sekbid/SekbidProgramKerja";
import SekbidStruktur from "@/components/sekbid/SekbidStruktur";
import SekbidInfoCards from "@/components/sekbid/SekbidInfoCards";
import {
  useActiveDepartments,
  useDepartmentMembers,
  useDepartmentPrograms,
} from "@/hooks/useApi";
import { getImageUrl } from "@/lib/utils";

import { Skeleton } from "@/components/ui/skeleton";

export default function DivisiPage({
  params,
}: {
  params: Promise<{ divisi: string }>;
}) {
  const { divisi } = use(params);
  const { data: departments, loading: loadingDepts } = useActiveDepartments();
  const dept = departments.find((d) => d.id === parseInt(divisi));

  const { data: apiMembers, loading: loadingMembers } = useDepartmentMembers(
    dept?.id || null,
  );
  const { data: apiPrograms, loading: loadingPrograms } = useDepartmentPrograms(
    dept?.id || null,
  );

  const mockData = getSekbidData(divisi);

  if (loadingDepts || loadingMembers || loadingPrograms) {
    return (
      <main className="min-h-screen pt-16 md:pt-20">
        <div className="px-6 md:px-8 md:mx-20">
          {/* Hero Skeleton */}
          <Skeleton className="w-full h-[200px] md:h-[400px] rounded-xl mb-10" />
          
          {/* Title & Description Skeleton */}
          <div className="space-y-4 mb-12">
            <Skeleton className="h-10 w-1/3" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-5/6" />
              <Skeleton className="h-4 w-4/6" />
            </div>
          </div>

          {/* Programs Skeleton */}
          <div className="space-y-6 mb-20">
             <Skeleton className="h-8 w-48" />
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Skeleton className="h-64 w-full rounded-lg" />
                <Skeleton className="h-64 w-full rounded-lg" />
                <Skeleton className="h-64 w-full rounded-lg" />
             </div>
          </div>
        </div>

        {/* Struktur Section Skeleton */}
        <div className="w-full bg-primary/10 py-16 mb-20">
           <div className="container mx-auto px-6 md:px-16 flex flex-col items-center gap-10">
              <Skeleton className="h-10 w-64" />
              <div className="flex flex-wrap justify-center gap-10 w-full">
                 {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="flex flex-col items-center gap-4">
                       <Skeleton className="w-32 h-44 rounded-md" />
                       <Skeleton className="h-4 w-24" />
                    </div>
                 ))}
              </div>
           </div>
        </div>
      </main>
    );
  }

  const transformedMembers =
    apiMembers.length > 0
      ? apiMembers.map((m) => ({
          name: m.name,
          role: m.position || "Anggota",
          photo: getImageUrl(
            m.image,
            "/assets/struktur-organisasi/pembina-placeholder.png",
          ),
        }))
      : [];

  const transformedPrograms =
    apiPrograms.length > 0
      ? apiPrograms.map((p) => ({
          name: p.name,
          description: p.description,
          image: getImageUrl(p.image, ""),
          coordinator: dept?.name || "OSIS",
          date: new Date(),
        }))
      : [];

  // Normalize data structure for the component
  const data = {
    id: dept?.id || mockData?.id || 0,
    title: dept?.name || mockData?.title || "",
    description: dept?.description || mockData?.description || "",
    heroImage: getImageUrl(
      dept?.thumbnail || mockData?.heroImage || null,
      "/assets/struktur-organisasi/sekbid-placeholder.png",
    ),
    logo: {
      image: getImageUrl(
        dept?.logo || mockData?.logo?.image || null,
        "/assets/struktur-organisasi/sekbid-placeholder.png",
      ),
      description: mockData?.logo?.description || "Logo Seksi Bidang",
    },
    tujuan: dept?.goal || mockData?.tujuan || [],
    tugasUtama: dept?.tasks || mockData?.tugasUtama || [],
    members: transformedMembers,
    programKerja: transformedPrograms,
    groupPhoto: dept?.thumbnail || mockData?.groupPhoto || "",
  };

  if (!data) {
    notFound();
  }

  return (
    <main className="min-h-screen pt-16 md:pt-20">
      <div className="px-6 md:px-8 md:mx-20">
        <SekbidHero heroImage={data.heroImage} />
        <SekbidDescription title={data.title} description={data.description} />
        {data.title === "Trimitra" ||
        data.title === "Sekretaris" ||
        data.title === "Bendahara" ? null : (
          <SekbidProgramKerja programs={data.programKerja} />
        )}
      </div>
      <SekbidStruktur
        members={data.members}
        groupPhoto={data.groupPhoto}
        sekbidId={data.id}
        sekbidTitle={data.title}
      />
      <div className="px-6 md:px-8 md:mx-20">
        <SekbidInfoCards
          tujuan={data.tujuan}
          logo={data.logo}
          tugasUtama={data.tugasUtama}
        />
      </div>
    </main>
  );
}
