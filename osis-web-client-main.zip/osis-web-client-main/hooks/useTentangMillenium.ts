import { useEffect, useState } from "react";
import { axiosInstance } from "@/lib/axios";

interface Program {
  id: number;
  title: string;
  date: string;
}

export function useTentangMilleniumVismis() {
  const [data, setData] = useState<Program[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTentangMillenium = async () => {
      try {
        const response = await axiosInstance.get("/api/landing/heroes");
        setData(response.data);
      } catch (err) {
        setError("Failed to fetch prestasi");
      } finally {
        setLoading(false);
      }
    };

    fetchTentangMillenium();
  }, []);

  return { data, loading, error };
}

export function useTentangMilleniumAsas() {
  const [data, setData] = useState<Program[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTentangMilleniumAsas = async () => {
      try {
        const response = await axiosInstance.get("/api/landing/achievements");
        setData(response.data);
      } catch (err) {
        setError("Failed to fetch prestasi");
      } finally {
        setLoading(false);
      }
    };

    fetchTentangMilleniumAsas();
  }, []);

  return { data, loading, error };
}

export function useTentangKamiSifat() {
  const [data, setData] = useState<Program[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchTentangKamiSifat = async () => {
      try {
        const response = await axiosInstance.get("/api/landing/carousels");
        setData(response.data);
      } catch (err) {
        setError("Failed to fetch prestasi");
      } finally {
        setLoading(false);
      }
    };

    fetchTentangKamiSifat();
  }, []);

  return { data, loading, error };
}
