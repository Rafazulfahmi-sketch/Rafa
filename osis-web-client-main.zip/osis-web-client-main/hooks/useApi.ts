import { useEffect, useState } from "react";
import { axiosInstance } from "@/lib/axios";

// --- Types ---

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  meta?: any;
}

export interface Achievement {
  id: number;
  title: string;
  thumbnail: string | null;
  date: string;
  description: string;
  participant: string;
}

export interface Carousel {
  id: number;
  image: string | null;
  order: number;
}

export interface LandingHero {
  id: number;
  image: string | null;
  order: number;
}

export interface Department {
  id: number;
  name: string;
  thumbnail: string | null;
  logo: string | null;
  description: string;
  goal: string[];
  tasks: string[];
}

export interface Program {
  id: number;
  name: string;
  image: string | null;
  description: string;
  order: number;
  department_id?: number;
  department_name?: string;
}

export interface Member {
  id: number;
  name: string;
  position: string;
  image: string | null;
}

export interface AboutContent {
  id: number;
  type: string;
  image: string | null;
  content: string;
  vision?: string;
  mission?: string;
}

export interface Advisor {
  id: number;
  name: string;
  image: string | null;
  message: string;
  born_date: string;
}

export interface StructureHero {
  id: number;
  image: string | null;
  title: string;
  order: number;
}

// --- Hooks ---

export function useLandingHeroes() {
  const [data, setData] = useState<LandingHero[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosInstance.get<ApiResponse<LandingHero[]>>("/api/landing/heroes").then((res) => {
      setData(res.data.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  return { data, loading };
}

export function useLandingAchievements() {
  const [data, setData] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosInstance.get<ApiResponse<Achievement[]>>("/api/landing/achievements").then((res) => {
      setData(res.data.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  return { data, loading };
}

export function useLandingCarousels() {
  const [data, setData] = useState<Carousel[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosInstance.get<ApiResponse<Carousel[]>>("/api/landing/carousels").then((res) => {
      setData(res.data.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  return { data, loading };
}

export function useAboutContent(type: "vision" | "mission" | "sifat" | "asas") {
  const [data, setData] = useState<AboutContent | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosInstance.get<ApiResponse<AboutContent>>(`/api/about/${type}`).then((res) => {
      setData(res.data.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [type]);

  return { data, loading };
}

export function useActiveDepartments() {
  const [data, setData] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosInstance.get<ApiResponse<Department[]>>("/api/period/active/departments").then((res) => {
      setData(res.data.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  return { data, loading };
}

export function useDepartmentMembers(id: number | null) {
  const [data, setData] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id === null) return;
    axiosInstance.get<ApiResponse<Member[]>>(`/api/departments/${id}/members`).then((res) => {
      setData(res.data.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [id]);

  return { data, loading };
}

export function useDepartmentPrograms(id: number | null) {
  const [data, setData] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id === null) return;
    axiosInstance.get<ApiResponse<Program[]>>(`/api/departments/${id}/programs`).then((res) => {
      setData(res.data.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [id]);

  return { data, loading };
}

export function useAllPrograms(recent?: number) {
  const [data, setData] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const url = recent ? `/api/period/active/programs?recent=${recent}` : "/api/period/active/programs";
    axiosInstance.get<ApiResponse<any>>(url).then((res) => {
      // Backend returns either flat array for recent, or nested by department
      if (recent) {
        setData(res.data.data);
      } else {
        // Flatten nested structure if needed, or return as is. 
        // For simplicity, let's just return raw data and handle in component.
        setData(res.data.data); 
      }
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [recent]);

  return { data, loading };
}

export function useStructureHeroes() {
  const [data, setData] = useState<StructureHero[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosInstance.get<ApiResponse<StructureHero[]>>("/api/period/active/structure").then((res) => {
      setData(res.data.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  return { data, loading };
}

export function useActiveAdvisors() {
  const [data, setData] = useState<Advisor[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axiosInstance.get<ApiResponse<Advisor[]>>("/api/period/active/advisors").then((res) => {
      setData(res.data.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  return { data, loading };
}
