import { useEffect, useState } from "react";
import { axiosInstance } from "@/lib/axios";

interface Program {
  id: number;
  title: string;
  date: string;
}

interface Params {
  page: number;
  limit: number;
  oldest?: boolean;
}

export function useLandingHeroes(params: Params) {
  const [data, setData] = useState<Program[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLandingHeroes = async () => {
      try {
        const response = await axiosInstance.get("/api/landing/heroes", {
          headers: {
            page: params.page,
            limit: params.limit,
            newest: params.oldest,
          },
        });
        setData(response.data);
      } catch (err) {
        setError("Failed to fetch prestasi");
      } finally {
        setLoading(false);
      }
    };

    fetchLandingHeroes();
  }, [params]);

  return { data, loading, error };
}

export function useLandingAchievements(params: Params) {
  const [data, setData] = useState<Program[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLandingAchievements = async () => {
      try {
        const response = await axiosInstance.get("/api/landing/achievements", {
          headers: {
            page: params.page,
            limit: params.limit,
            newest: params.oldest,
          },
        });
        setData(response.data);
      } catch (err) {
        setError("Failed to fetch prestasi");
      } finally {
        setLoading(false);
      }
    };

    fetchLandingAchievements();
  }, [params]);

  return { data, loading, error };
}

export function useLandingHeroCarousels(params: Params) {
  const [data, setData] = useState<Program[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLandingHeroCarousels = async () => {
      try {
        const response = await axiosInstance.get("/api/landing/carousels", {
          headers: {
            page: params.page,
            limit: params.limit,
            newest: params.oldest,
          },
        });
        setData(response.data);
      } catch (err) {
        setError("Failed to fetch prestasi");
      } finally {
        setLoading(false);
      }
    };

    fetchLandingHeroCarousels();
  }, [params]);

  return { data, loading, error };
}
