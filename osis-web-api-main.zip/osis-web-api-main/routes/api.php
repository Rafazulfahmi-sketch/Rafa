<?php

use App\Http\Controllers\Api\AboutController;
use App\Http\Controllers\Api\DepartmentController;
use App\Http\Controllers\Api\LandingController;
use App\Http\Controllers\Api\PeriodController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Landing Page
Route::get('/landing/heroes', [LandingController::class, 'heroes']);
Route::get('/landing/achievements', [LandingController::class, 'achievements']);
Route::get('/landing/carousels', [LandingController::class, 'carousels']);

// About Page
Route::get('/about/vision', [AboutController::class, 'vision']);
Route::get('/about/mission', [AboutController::class, 'mission']);
Route::get('/about/vismis', [AboutController::class, 'vismis']);
Route::get('/about/sifat', [AboutController::class, 'sifat']);
Route::get('/about/asas', [AboutController::class, 'asas']);

// Active Period Structure
Route::get('/period/active/structure', [PeriodController::class, 'structure']);
Route::get('/period/active/advisors', [PeriodController::class, 'advisors']);

// Departments (Active Period)
Route::get('/period/active/departments', [DepartmentController::class, 'index']);
Route::get('/period/active/programs', [DepartmentController::class, 'allPrograms']);
Route::get('/departments/{id}/members', [DepartmentController::class, 'members']);
Route::get('/departments/{id}/programs', [DepartmentController::class, 'programs']);
Route::get('/departments/{id}/achievements', [DepartmentController::class, 'achievements']);
