# OSIS CMS API

CMS + REST API untuk website company profile OSIS SMKN 1 Cibinong. Dibangun dengan Laravel 12 + Filament v3.

## Fitur Utama

- 📅 **Period-Centric Architecture** - Data terorganisir per periode kepengurusan
- 🔒 **Archive Immutability** - Periode arsip tidak dapat diubah
- 👥 **Role-Based Access** - Super Admin & Editor
- 🖼️ **Gallery Management** - Drag & drop ordering
- 🌐 **Public REST API** - Read-only endpoints

---

## Setup & Installation

### Prerequisites
- PHP 8.2+
- Composer
- SQLite / MySQL

### Installation

```bash
# Clone repository
git clone <repository-url>
cd osis-web-api

# Install dependencies
composer install

# Copy environment file
cp .env.example .env

# Generate app key
php artisan key:generate

# Run migrations
php artisan migrate

# Create storage symlink
php artisan storage:link

# Seed roles & default users
php artisan db:seed --class=RoleSeeder
```

### Start Server

```bash
php artisan serve
```

- **Admin Panel**: http://localhost:8000/admin
- **API Base URL**: http://localhost:8000/api

---

## User Management

### Default Users (from RoleSeeder)

| Role | Email | Password |
|------|-------|----------|
| Super Admin | admin@example.com | password |
| Editor | editor@example.com | password |

### Add Super Admin via Tinker

```bash
php artisan tinker
```

```php
// Create user
$user = \App\Models\User::create([
    'name' => 'Nama Admin',
    'email' => 'admin.baru@example.com',
    'password' => bcrypt('password123'),
]);

// Assign super_admin role
$user->assignRole('super_admin');
```

### Add Editor via Tinker

```php
$user = \App\Models\User::create([
    'name' => 'Nama Editor',
    'email' => 'editor.baru@example.com',
    'password' => bcrypt('password123'),
]);

$user->assignRole('editor');
```

### Role Permissions

| Action | Super Admin | Editor |
|--------|-------------|--------|
| Manage Period | ✅ | ❌ |
| Set Active Period | ✅ | ❌ |
| CRUD Content | ✅ | ✅ |
| Edit Archive | ❌ | ❌ |

---

## Admin Panel Usage

### 1. Create Period (Super Admin Only)

1. Login ke `/admin`
2. Klik **Periods** di sidebar
3. Klik **Create Period**
4. Isi nama periode (contoh: "2024/2025")
5. Save

### 2. Activate Period

1. Buka daftar Periods
2. Klik tombol **Set Active** pada periode yang diinginkan
3. Konfirmasi aktivasi

> ⚠️ Hanya satu periode yang bisa aktif. Mengaktifkan periode baru akan menonaktifkan periode sebelumnya.

### 3. Add Departments (Sekbid)

1. Buka detail Period (View)
2. Scroll ke tab **Departments (Sekbid)**
3. Klik **Create**
4. Isi: Name, Thumbnail, Logo, Description, Goal, Tasks
5. Save

### 4. Add Members & Programs

1. Buka detail Department
2. Gunakan tab **Members** untuk menambah anggota
3. Gunakan tab **Programs** untuk menambah program kerja
4. Gunakan tab **Family Photos** untuk foto keluarga

### 5. Global Content

- **Achievements**: Menu Content → Achievements
- **Landing Heroes**: Menu Landing Page → Hero Slides
- **Carousels**: Menu Landing Page → Carousels
- **About**: Menu Content → About Page (max 3 records)

---

## REST API Endpoints

### Response Format

```json
{
  "success": true,
  "data": [...],
  "meta": {
    "total": 10
  }
}
```

### Landing Page

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/landing/heroes` | Hero slides |
| GET | `/api/landing/achievements` | All achievements |
| GET | `/api/landing/carousels` | Carousel images |

### About Page

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/about/vismis` | Vision & Mission |
| GET | `/api/about/sifat` | Sifat OSIS |
| GET | `/api/about/asas` | Asas OSIS |

### Active Period

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/period/active/structure` | Structure heroes |
| GET | `/api/period/active/advisors` | Advisors (Pembina) |
| GET | `/api/period/active/departments` | All departments |

### Department Details

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/departments/{id}/members` | Members |
| GET | `/api/departments/{id}/programs` | Work programs |
| GET | `/api/departments/{id}/achievements` | Achievements |

### Example Requests

```bash
# Get landing heroes
curl http://localhost:8000/api/landing/heroes

# Get active period departments
curl http://localhost:8000/api/period/active/departments

# Get department members
curl http://localhost:8000/api/departments/1/members
```

### Example Response

```json
// GET /api/period/active/departments
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Sekbid 1 - Ketaqwaan",
      "thumbnail": "http://localhost:8000/storage/departments/thumbnails/xxx.jpg",
      "logo": "http://localhost:8000/storage/departments/logos/xxx.png",
      "description": "Deskripsi sekbid...",
      "goal": "Tujuan sekbid...",
      "tasks": "Tugas-tugas..."
    }
  ],
  "meta": {
    "period": "2024/2025",
    "total": 1
  }
}
```

---

## Database Structure

```
periods
├── structure_heroes
├── advisors
└── departments
    ├── department_images
    ├── members
    └── programs

achievements (global)
landing_heroes (global)
carousels (global)
about_contents (global, max 3)
```

---

## Important Rules

1. **Single Active Period**: Hanya 1 periode aktif pada satu waktu
2. **Archive Immutable**: Periode non-aktif tidak dapat dimodifikasi
3. **About Content Limit**: Maksimal 3 record (vismis, sifat, asas)
4. **Gallery Ordering**: Semua gallery menggunakan manual ordering

---

## Tech Stack

- Laravel 12
- Filament v3
- Spatie Laravel Permission
- Spatie Media Library
- SQLite (default) / MySQL

---

## License

MIT
