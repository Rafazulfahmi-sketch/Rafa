<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('about_contents', function (Blueprint $table) {
            if (!Schema::hasColumn('about_contents', 'vision')) {
                $table->text('vision')->nullable()->after('content');
            }
            if (!Schema::hasColumn('about_contents', 'mission')) {
                // If vision was just added or already exists, we can place it after
                if (Schema::hasColumn('about_contents', 'vision')) {
                    $table->text('mission')->nullable()->after('vision');
                } else {
                    $table->text('mission')->nullable()->after('content');
                }
            }
        });

        // Ensure existing 'vision' or 'mission' type records are converted to 'vismis'
        DB::table('about_contents')->where('type', 'vision')->update(['type' => 'vismis']);
        DB::table('about_contents')->where('type', 'mission')->update(['type' => 'vismis']);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('about_contents', function (Blueprint $table) {
            $table->dropColumn(['vision', 'mission']);
        });
    }
};
