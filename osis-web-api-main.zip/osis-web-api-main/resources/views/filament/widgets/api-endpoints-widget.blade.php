<x-filament-widgets::widget>
    <x-filament::section>
        <x-slot name="heading">
            <div class="flex items-center gap-2">
                <x-heroicon-o-globe-alt class="w-5 h-5 text-primary-500" />
                <span>API Endpoints</span>
            </div>
        </x-slot>
        
        <x-slot name="description">
            Base URL: <code class="px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded text-sm font-mono">{{ $this->getBaseUrl() }}</code>
        </x-slot>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            @foreach($this->getEndpoints() as $group)
                <div class="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
                    <h4 class="font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                        <x-heroicon-o-folder class="w-4 h-4" />
                        {{ $group['group'] }}
                    </h4>
                    <div class="space-y-2">
                        @foreach($group['endpoints'] as $endpoint)
                            <div class="flex items-start gap-2 text-sm">
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100">
                                    {{ $endpoint['method'] }}
                                </span>
                                <div class="flex-1 min-w-0">
                                    <code class="text-xs font-mono text-gray-700 dark:text-gray-300 break-all">{{ $endpoint['path'] }}</code>
                                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{{ $endpoint['description'] }}</p>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endforeach
        </div>

        <div class="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <p class="text-xs text-blue-700 dark:text-blue-300">
                <x-heroicon-o-information-circle class="w-4 h-4 inline mr-1" />
                Semua endpoint bersifat <strong>public read-only</strong>. Response format: <code class="bg-blue-100 dark:bg-blue-800 px-1 rounded">{"success": true, "data": [...], "meta": {...}}</code>
            </p>
        </div>
    </x-filament::section>
</x-filament-widgets::widget>
