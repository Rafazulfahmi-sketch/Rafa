<?php

namespace App\Policies;

use App\Models\Member;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class MemberPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any members.
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can view the member.
     */
    public function view(User $user, Member $member): bool
    {
        return true;
    }

    /**
     * Determine whether the user can create members.
     */
    public function create(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can update the member.
     * Cannot update if parent period is archived.
     */
    public function update(User $user, Member $member): bool
    {
        return !$member->isArchived();
    }

    /**
     * Determine whether the user can delete the member.
     * Cannot delete if parent period is archived.
     */
    public function delete(User $user, Member $member): bool
    {
        return !$member->isArchived();
    }
}
