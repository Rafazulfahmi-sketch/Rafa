<?php

namespace App\Policies;

use App\Models\DepartmentImage;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class DepartmentImagePolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user): bool
    {
        return true;
    }

    public function view(User $user, DepartmentImage $departmentImage): bool
    {
        return true;
    }

    public function create(User $user): bool
    {
        return true;
    }

    public function update(User $user, DepartmentImage $departmentImage): bool
    {
        return !$departmentImage->isArchived();
    }

    public function delete(User $user, DepartmentImage $departmentImage): bool
    {
        return !$departmentImage->isArchived();
    }
}
