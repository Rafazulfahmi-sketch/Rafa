<?php

namespace App\Policies;

use App\Models\Advisor;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class AdvisorPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user): bool
    {
        return true;
    }

    public function view(User $user, Advisor $advisor): bool
    {
        return true;
    }

    public function create(User $user): bool
    {
        return true;
    }

    public function update(User $user, Advisor $advisor): bool
    {
        return !$advisor->isArchived();
    }

    public function delete(User $user, Advisor $advisor): bool
    {
        return !$advisor->isArchived();
    }
}
