<?php

namespace App\Policies;

use App\Models\Program;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class ProgramPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any programs.
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can view the program.
     */
    public function view(User $user, Program $program): bool
    {
        return true;
    }

    /**
     * Determine whether the user can create programs.
     */
    public function create(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can update the program.
     * Cannot update if parent period is archived.
     */
    public function update(User $user, Program $program): bool
    {
        return !$program->isArchived();
    }

    /**
     * Determine whether the user can delete the program.
     * Cannot delete if parent period is archived.
     */
    public function delete(User $user, Program $program): bool
    {
        return !$program->isArchived();
    }
}
