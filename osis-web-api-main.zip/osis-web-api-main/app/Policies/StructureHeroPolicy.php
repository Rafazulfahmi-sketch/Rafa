<?php

namespace App\Policies;

use App\Models\StructureHero;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class StructureHeroPolicy
{
    use HandlesAuthorization;

    public function viewAny(User $user): bool
    {
        return true;
    }

    public function view(User $user, StructureHero $structureHero): bool
    {
        return true;
    }

    public function create(User $user): bool
    {
        return true;
    }

    public function update(User $user, StructureHero $structureHero): bool
    {
        return !$structureHero->isArchived();
    }

    public function delete(User $user, StructureHero $structureHero): bool
    {
        return !$structureHero->isArchived();
    }
}
