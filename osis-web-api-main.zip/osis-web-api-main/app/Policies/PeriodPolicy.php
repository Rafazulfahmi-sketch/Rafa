<?php

namespace App\Policies;

use App\Models\Period;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PeriodPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any periods.
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can view the period.
     */
    public function view(User $user, Period $period): bool
    {
        return true;
    }

    /**
     * Determine whether the user can create periods.
     * Only super_admin can create periods.
     */
    public function create(User $user): bool
    {
        return $user->hasRole('super_admin');
    }

    /**
     * Determine whether the user can update the period.
     * Only super_admin can update, and only active periods can be edited.
     */
    public function update(User $user, Period $period): bool
    {
        // Archived periods cannot be edited by anyone
        if ($period->isArchived()) {
            return false;
        }

        return $user->hasRole('super_admin');
    }

    /**
     * Determine whether the user can delete the period.
     * Only super_admin can delete, and only if no relations exist.
     */
    public function delete(User $user, Period $period): bool
    {
        if (!$user->hasRole('super_admin')) {
            return false;
        }

        // Cannot delete period with existing relations
        if ($period->departments()->exists() ||
            $period->structureHeroes()->exists() ||
            $period->advisors()->exists()) {
            return false;
        }

        return true;
    }

    /**
     * Determine whether the user can toggle active status.
     * Only super_admin can toggle.
     */
    public function toggleActive(User $user, Period $period): bool
    {
        return $user->hasRole('super_admin');
    }
}
