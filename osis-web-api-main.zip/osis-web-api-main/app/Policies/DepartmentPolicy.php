<?php

namespace App\Policies;

use App\Models\Department;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class DepartmentPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any departments.
     */
    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can view the department.
     */
    public function view(User $user, Department $department): bool
    {
        return true;
    }

    /**
     * Determine whether the user can create departments.
     * Both roles can create, but only in active periods.
     */
    public function create(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can update the department.
     * Both roles can update, but only in active periods.
     */
    public function update(User $user, Department $department): bool
    {
        // Cannot modify departments in archived periods
        return !$department->isArchived();
    }

    /**
     * Determine whether the user can delete the department.
     * Both roles can delete, but only in active periods.
     */
    public function delete(User $user, Department $department): bool
    {
        // Cannot delete departments in archived periods
        return !$department->isArchived();
    }
}
