<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        \App\Models\Period::class => \App\Policies\PeriodPolicy::class,
        \App\Models\Department::class => \App\Policies\DepartmentPolicy::class,
        \App\Models\Member::class => \App\Policies\MemberPolicy::class,
        \App\Models\Program::class => \App\Policies\ProgramPolicy::class,
        \App\Models\StructureHero::class => \App\Policies\StructureHeroPolicy::class,
        \App\Models\Advisor::class => \App\Policies\AdvisorPolicy::class,
        \App\Models\DepartmentImage::class => \App\Policies\DepartmentImagePolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();
    }
}
