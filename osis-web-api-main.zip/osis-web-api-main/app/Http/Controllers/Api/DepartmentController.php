<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Achievement;
use App\Models\Department;
use App\Models\Period;
use App\Models\Program;
use App\Traits\ApiResponse;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/period/active/departments
     */
    public function index()
    {
        $period = Period::active()->first();

        if (!$period) {
            return $this->success([], [
                'message' => 'No active period found',
            ]);
        }

        $departments = $period->departments()
            ->get()
            ->map(fn ($dept) => [
                'id' => $dept->id,
                'name' => $dept->name,
                'thumbnail' => $dept->thumbnail ? asset('storage/' . $dept->thumbnail) : null,
                'logo' => $dept->logo ? asset('storage/' . $dept->logo) : null,
                'description' => $dept->description,
                'goal' => array_values(array_filter(explode("\n", (string) $dept->goal))),
                'tasks' => array_values(array_filter(explode("\n", (string) $dept->tasks))),
            ]);

        return $this->success($departments, [
            'period' => $period->name,
            'total' => $departments->count(),
        ]);
    }

    /**
     * GET /api/departments/{id}/members
     */
    public function members(int $id)
    {
        $department = Department::find($id);

        if (!$department) {
            return $this->error('Department not found', 404);
        }

        if (!$department->isFromActivePeriod()) {
            return $this->error('This department is not from the active period', 400);
        }

        $members = $department->members()
            ->get()
            ->map(fn ($member) => [
                'id' => $member->id,
                'name' => $member->name,
                'position' => $member->position,
                'image' => $member->image ? asset('storage/' . $member->image) : null,
            ]);

        return $this->success($members, [
            'department' => $department->name,
            'total' => $members->count(),
        ]);
    }

    /**
     * GET /api/departments/{id}/programs
     */
    public function programs(int $id)
    {
        $department = Department::find($id);

        if (!$department) {
            return $this->error('Department not found', 404);
        }

        if (!$department->isFromActivePeriod()) {
            return $this->error('This department is not from the active period', 400);
        }

        $programs = $department->programs()
            ->orderBy('order')
            ->get()
            ->map(fn ($program) => [
                'id' => $program->id,
                'name' => $program->name,
                'image' => $program->image ? asset('storage/' . $program->image) : null,
                'description' => $program->description,
                'order' => $program->order,
            ]);

        return $this->success($programs, [
            'department' => $department->name,
            'total' => $programs->count(),
        ]);
    }

    /**
     * GET /api/departments/{id}/achievements
     * Note: Achievements are global, this returns all achievements
     */
    public function achievements(int $id)
    {
        $department = Department::find($id);

        if (!$department) {
            return $this->error('Department not found', 404);
        }

        // Achievements are global (not department-specific)
        // Return all achievements for landing/sekbid display
        $achievements = Achievement::latest('date')
            ->get()
            ->map(fn ($achievement) => [
                'id' => $achievement->id,
                'title' => $achievement->title,
                'thumbnail' => $achievement->thumbnail ? asset('storage/' . $achievement->thumbnail) : null,
                'date' => $achievement->date?->format('Y-m-d'),
                'description' => $achievement->description,
                'participant' => $achievement->participant,
            ]);

        return $this->success($achievements, [
            'department' => $department->name,
            'total' => $achievements->count(),
        ]);
    }

    /**
     * GET /api/period/active/programs
     * Returns all programs from all departments in the active period.
     * Optional query: ?recent=N to get the N most recent programs.
     */
    public function allPrograms(Request $request)
    {
        $period = Period::active()->first();

        if (!$period) {
            return $this->success([], [
                'message' => 'No active period found',
            ]);
        }

        $recent = $request->query('recent');

        if ($recent && is_numeric($recent)) {
            $programs = Program::whereHas('department', fn ($q) => $q->where('period_id', $period->id))
                ->with('department:id,name')
                ->latest()
                ->take((int) $recent)
                ->get()
                ->map(fn ($program) => [
                    'id' => $program->id,
                    'name' => $program->name,
                    'image' => $program->image ? asset('storage/' . $program->image) : null,
                    'description' => $program->description,
                    'order' => $program->order,
                    'department_id' => $program->department->id,
                    'department_name' => $program->department->name,
                ]);

            return $this->success($programs, [
                'period' => $period->name,
                'total_programs' => $programs->count(),
            ]);
        }

        $departments = $period->departments()
            ->with(['programs' => fn ($q) => $q->orderBy('order')])
            ->get();

        $totalPrograms = 0;

        $data = $departments->map(function ($dept) use (&$totalPrograms) {
            $programs = $dept->programs->map(fn ($program) => [
                'id' => $program->id,
                'name' => $program->name,
                'image' => $program->image ? asset('storage/' . $program->image) : null,
                'description' => $program->description,
                'order' => $program->order,
            ]);

            $totalPrograms += $programs->count();

            return [
                'department_id' => $dept->id,
                'department_name' => $dept->name,
                'programs' => $programs,
            ];
        });

        return $this->success($data, [
            'period' => $period->name,
            'total_departments' => $departments->count(),
            'total_programs' => $totalPrograms,
        ]);
    }
}
