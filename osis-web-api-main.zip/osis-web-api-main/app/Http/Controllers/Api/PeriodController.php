<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Period;
use App\Traits\ApiResponse;

class PeriodController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/period/active/structure
     */
    public function structure()
    {
        $period = Period::active()->first();

        if (!$period) {
            return $this->success([], [
                'message' => 'No active period found',
            ]);
        }

        $heroes = $period->structureHeroes()
            ->orderBy('order')
            ->get()
            ->map(fn ($hero) => [
                'id' => $hero->id,
                'image' => $hero->image ? asset('storage/' . $hero->image) : null,
                'title' => $hero->title,
                'order' => $hero->order,
            ]);

        return $this->success($heroes, [
            'period' => $period->name,
            'total' => $heroes->count(),
        ]);
    }

    /**
     * GET /api/period/active/advisors
     */
    public function advisors()
    {
        $period = Period::active()->first();

        if (!$period) {
            return $this->success([], [
                'message' => 'No active period found',
            ]);
        }

        $advisors = $period->advisors()
            ->get()
            ->map(fn ($advisor) => [
                'id' => $advisor->id,
                'name' => $advisor->name,
                'image' => $advisor->image ? asset('storage/' . $advisor->image) : null,
                'message' => $advisor->message,
                'born_date' => $advisor->born_date?->format('Y-m-d'),
            ]);

        return $this->success($advisors, [
            'period' => $period->name,
            'total' => $advisors->count(),
        ]);
    }
}
