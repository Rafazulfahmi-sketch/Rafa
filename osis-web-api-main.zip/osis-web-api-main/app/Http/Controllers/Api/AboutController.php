<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AboutContent;
use App\Traits\ApiResponse;

class AboutController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/about/vision
     */
    public function vision()
    {
        $content = AboutContent::vismis();

        if (!$content) {
            return $this->success(null, [
                'message' => 'Vision & Mission content not found',
            ]);
        }

        return $this->success([
            'id' => $content->id,
            'type' => 'vision',
            'image' => $content->image ? asset('storage/' . $content->image) : null,
            'content' => $content->vision,
        ]);
    }

    /**
     * GET /api/about/mission
     */
    public function mission()
    {
        $content = AboutContent::vismis();

        if (!$content) {
            return $this->success(null, [
                'message' => 'Vision & Mission content not found',
            ]);
        }

        return $this->success([
            'id' => $content->id,
            'type' => 'mission',
            'image' => $content->image ? asset('storage/' . $content->image) : null,
            'content' => $content->mission,
        ]);
    }

    /**
     * GET /api/about/vismis
     */
    public function vismis()
    {
        $content = AboutContent::vismis();

        if (!$content) {
            return $this->success(null, [
                'message' => 'Vision & Mission content not found',
            ]);
        }

        return $this->success([
            'id' => $content->id,
            'type' => $content->type,
            'image' => $content->image ? asset('storage/' . $content->image) : null,
            'vision' => $content->vision,
            'mission' => $content->mission,
            'content' => $content->vision . $content->mission, // Fallback
        ]);
    }

    /**
     * GET /api/about/sifat
     */
    public function sifat()
    {
        $content = AboutContent::sifat();

        if (!$content) {
            return $this->success(null, [
                'message' => 'Sifat content not found',
            ]);
        }

        return $this->success([
            'id' => $content->id,
            'type' => $content->type,
            'image' => $content->image ? asset('storage/' . $content->image) : null,
            'content' => $content->content,
        ]);
    }

    /**
     * GET /api/about/asas
     */
    public function asas()
    {
        $content = AboutContent::asas();

        if (!$content) {
            return $this->success(null, [
                'message' => 'Asas content not found',
            ]);
        }

        return $this->success([
            'id' => $content->id,
            'type' => $content->type,
            'image' => $content->image ? asset('storage/' . $content->image) : null,
            'content' => $content->content,
        ]);
    }
}
