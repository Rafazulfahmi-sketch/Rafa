<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Achievement;
use App\Models\Carousel;
use App\Models\LandingHero;
use App\Traits\ApiResponse;

class LandingController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/landing/heroes
     */
    public function heroes()
    {
        $heroes = LandingHero::ordered()
            ->get()
            ->map(fn ($hero) => [
                'id' => $hero->id,
                'image' => $hero->image ? asset('storage/' . $hero->image) : null,
                'order' => $hero->order,
            ]);

        return $this->success($heroes, [
            'total' => $heroes->count(),
        ]);
    }

    /**
     * GET /api/landing/achievements
     */
    public function achievements()
    {
        $achievements = Achievement::latest('date')
            ->get()
            ->map(fn ($achievement) => [
                'id' => $achievement->id,
                'title' => $achievement->title,
                'thumbnail' => $achievement->thumbnail ? asset('storage/' . $achievement->thumbnail) : null,
                'date' => $achievement->date?->format('Y-m-d'),
                'description' => $achievement->description,
                'participant' => $achievement->participant,
            ]);

        return $this->success($achievements, [
            'total' => $achievements->count(),
        ]);
    }

    /**
     * GET /api/landing/carousels
     */
    public function carousels()
    {
        $carousels = Carousel::ordered()
            ->get()
            ->map(fn ($carousel) => [
                'id' => $carousel->id,
                'image' => $carousel->image ? asset('storage/' . $carousel->image) : null,
                'order' => $carousel->order,
            ]);

        return $this->success($carousels, [
            'total' => $carousels->count(),
        ]);
    }
}
