<?php

namespace App\Traits;

trait ApiResponse
{
    /**
     * Return successful response.
     */
    protected function success($data, array $meta = null)
    {
        $response = [
            'success' => true,
            'data' => $data,
        ];

        if ($meta !== null) {
            $response['meta'] = $meta;
        }

        return response()->json($response);
    }

    /**
     * Return error response.
     */
    protected function error(string $message, int $code = 404)
    {
        return response()->json([
            'success' => false,
            'message' => $message,
        ], $code);
    }
}
