<?php

namespace App\Traits;

use Filament\Forms\Components\FileUpload;

trait HasOptimizedImageUpload
{
    /**
     * Create an optimized image upload field.
     *
     * @param string $name Field name
     * @param string $directory Storage directory
     * @param int $maxWidth Maximum width for resize
     * @param int $maxHeight Maximum height for resize
     * @param int $quality Image quality (1-100)
     * @param int $maxSize Max file size in KB
     */
    protected static function makeOptimizedImageUpload(
        string $name,
        string $directory,
        int $maxWidth = 1920,
        int $maxHeight = 1080,
        int $quality = 80,
        int $maxSize = 2048
    ): FileUpload {
        return FileUpload::make($name)
            ->image()
            ->disk('public')
            ->directory($directory)
            ->imageResizeMode('cover')
            ->imageResizeTargetWidth($maxWidth)
            ->imageResizeTargetHeight($maxHeight)
            ->imageResizeUpscale(false)
            ->maxSize($maxSize)
            ->optimize('jpg')
            ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/webp']);
    }

    /**
     * Create thumbnail upload (small images).
     */
    protected static function makeThumbnailUpload(string $name, string $directory): FileUpload
    {
        return static::makeOptimizedImageUpload($name, $directory, 800, 600, 75, 5120);
    }

    /**
     * Create logo upload (icons/logos).
     */
    protected static function makeLogoUpload(string $name, string $directory): FileUpload
    {
        return static::makeOptimizedImageUpload($name, $directory, 500, 500, 80, 5120);
    }

    /**
     * Create hero/banner upload (large images).
     */
    protected static function makeHeroUpload(string $name, string $directory): FileUpload
    {
        return static::makeOptimizedImageUpload($name, $directory, 1920, 1080, 85, 5120);
    }

    /**
     * Create profile photo upload.
     */
    protected static function makeProfileUpload(string $name, string $directory): FileUpload
    {
        return static::makeOptimizedImageUpload($name, $directory, 400, 400, 80, 5120);
    }
}
