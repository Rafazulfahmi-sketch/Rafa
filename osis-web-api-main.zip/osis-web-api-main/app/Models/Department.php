<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Department extends Model
{
    protected $fillable = [
        'period_id',
        'name',
        'thumbnail',
        'logo',
        'description',
        'goal',
        'tasks',
    ];

    /**
     * Get the period this department belongs to.
     */
    public function period(): BelongsTo
    {
        return $this->belongsTo(Period::class);
    }

    /**
     * Get members of this department.
     */
    public function members(): HasMany
    {
        return $this->hasMany(Member::class);
    }

    /**
     * Get programs of this department.
     */
    public function programs(): HasMany
    {
        return $this->hasMany(Program::class)->orderBy('order');
    }

    /**
     * Get images (family photos) of this department.
     */
    public function images(): HasMany
    {
        return $this->hasMany(DepartmentImage::class)->orderBy('order');
    }

    /**
     * Check if parent period is archived.
     */
    public function isArchived(): bool
    {
        return $this->period->isArchived();
    }

    /**
     * Check if this department belongs to the active period.
     */
    public function isFromActivePeriod(): bool
    {
        return $this->period->is_active;
    }
}
