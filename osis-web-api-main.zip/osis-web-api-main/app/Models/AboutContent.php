<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AboutContent extends Model
{
    protected $fillable = [
        'type',
        'image',
        'content',
        'vision',
        'mission',
    ];

    /**
     * Available types for about content.
     */
    public const TYPES = ['vismis', 'sifat', 'asas'];

    /**
     * Scope to find by type.
     */
    public function scopeOfType($query, string $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Get vision & mission content.
     */
    public static function vismis()
    {
        return static::ofType('vismis')->first();
    }

    /**
     * Get sifat content.
     */
    public static function sifat()
    {
        return static::ofType('sifat')->first();
    }

    /**
     * Get asas content.
     */
    public static function asas()
    {
        return static::ofType('asas')->first();
    }
}
