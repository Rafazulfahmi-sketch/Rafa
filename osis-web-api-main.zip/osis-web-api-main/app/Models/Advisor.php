<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Advisor extends Model
{
    protected $fillable = [
        'period_id',
        'name',
        'image',
        'message',
        'born_date',
    ];

    protected $casts = [
        'born_date' => 'date',
    ];

    /**
     * Get the period this advisor belongs to.
     */
    public function period(): BelongsTo
    {
        return $this->belongsTo(Period::class);
    }

    /**
     * Check if parent period is archived.
     */
    public function isArchived(): bool
    {
        return $this->period->isArchived();
    }
}
