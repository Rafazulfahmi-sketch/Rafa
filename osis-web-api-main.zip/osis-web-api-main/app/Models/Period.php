<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Period extends Model
{
    protected $fillable = [
        'name',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    /**
     * Scope to get active period only.
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope to get archived (non-active) periods.
     */
    public function scopeArchived($query)
    {
        return $query->where('is_active', false);
    }

    /**
     * Check if period is archived (not active).
     */
    public function isArchived(): bool
    {
        return !$this->is_active;
    }

    /**
     * Get structure heroes for this period.
     */
    public function structureHeroes(): HasMany
    {
        return $this->hasMany(StructureHero::class)->orderBy('order');
    }

    /**
     * Get advisors for this period.
     */
    public function advisors(): HasMany
    {
        return $this->hasMany(Advisor::class);
    }

    /**
     * Get departments for this period.
     */
    public function departments(): HasMany
    {
        return $this->hasMany(Department::class);
    }
}
