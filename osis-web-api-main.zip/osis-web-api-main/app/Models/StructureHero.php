<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StructureHero extends Model
{
    protected $fillable = [
        'period_id',
        'image',
        'title',
        'order',
    ];

    protected $casts = [
        'order' => 'integer',
    ];

    /**
     * Get the period this structure hero belongs to.
     */
    public function period(): BelongsTo
    {
        return $this->belongsTo(Period::class);
    }

    /**
     * Check if parent period is archived.
     */
    public function isArchived(): bool
    {
        return $this->period->isArchived();
    }
}
