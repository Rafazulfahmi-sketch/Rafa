<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Achievement extends Model
{
    protected $fillable = [
        'title',
        'thumbnail',
        'date',
        'description',
        'participant',
    ];

    protected $casts = [
        'date' => 'date',
    ];
}
