<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Member extends Model
{
    protected $fillable = [
        'department_id',
        'name',
        'position',
        'image',
    ];

    /**
     * Get the department this member belongs to.
     */
    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }

    /**
     * Check if parent period is archived.
     */
    public function isArchived(): bool
    {
        return $this->department->isArchived();
    }
}
