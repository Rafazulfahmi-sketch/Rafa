<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DepartmentImage extends Model
{
    protected $fillable = [
        'department_id',
        'image',
        'order',
    ];

    protected $casts = [
        'order' => 'integer',
    ];

    /**
     * Get the department this image belongs to.
     */
    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }

    /**
     * Check if parent period is archived.
     */
    public function isArchived(): bool
    {
        return $this->department->isArchived();
    }
}
