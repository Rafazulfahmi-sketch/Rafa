<?php

namespace App\Filament\Resources\LandingHeroResource\Pages;

use App\Filament\Resources\LandingHeroResource;
use Filament\Resources\Pages\CreateRecord;

class CreateLandingHero extends CreateRecord
{
    protected static string $resource = LandingHeroResource::class;
}
