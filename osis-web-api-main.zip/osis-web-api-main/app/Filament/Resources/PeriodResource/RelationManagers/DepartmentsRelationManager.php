<?php

namespace App\Filament\Resources\PeriodResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;

class DepartmentsRelationManager extends RelationManager
{
    protected static string $relationship = 'departments';

    protected static ?string $title = 'Departments (Sekbid)';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('name')
                    ->required()
                    ->maxLength(255),
                Forms\Components\FileUpload::make('thumbnail')
                    ->image()
                    ->disk('public')
                    ->directory('departments/thumbnails')
                    ->imageResizeMode('cover')
                    ->imageResizeTargetWidth(800)
                    ->imageResizeTargetHeight(600)
                    ->imageResizeUpscale(false)
                    ->maxSize(5120)
                    ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/webp']),
                Forms\Components\FileUpload::make('logo')
                    ->image()
                    ->disk('public')
                    ->directory('departments/logos')
                    ->imageResizeMode('contain')
                    ->imageResizeTargetWidth(500)
                    ->imageResizeTargetHeight(500)
                    ->imageResizeUpscale(false)
                    ->maxSize(5120)
                    ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/webp']),
                Forms\Components\Textarea::make('description')
                    ->rows(3),
                Forms\Components\Textarea::make('goal')
                    ->label('Goals')
                    ->rows(2),
                Forms\Components\Textarea::make('tasks')
                    ->rows(2),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('thumbnail')
                    ->disk('public')
                    ->square(),
                Tables\Columns\TextColumn::make('name')
                    ->searchable(),
                Tables\Columns\TextColumn::make('members_count')
                    ->counts('members')
                    ->label('Members'),
                Tables\Columns\TextColumn::make('programs_count')
                    ->counts('programs')
                    ->label('Programs'),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()
                    ->visible(fn () => !$this->getOwnerRecord()->isArchived()),
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make()
                    ->visible(fn () => !$this->getOwnerRecord()->isArchived()),
                Tables\Actions\DeleteAction::make()
                    ->visible(fn () => !$this->getOwnerRecord()->isArchived()),
            ])
            ->bulkActions([]);
    }
}
