<?php

namespace App\Filament\Resources\PeriodResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;

class AdvisorsRelationManager extends RelationManager
{
    protected static string $relationship = 'advisors';

    protected static ?string $title = 'Advisors (Pembina)';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('name')
                    ->required()
                    ->maxLength(255),
                Forms\Components\FileUpload::make('image')
                    ->image()
                    ->disk('public')
                    ->directory('advisors')
                    ->required()
                    ->imageResizeMode('cover')
                    ->imageResizeTargetWidth(400)
                    ->imageResizeTargetHeight(400)
                    ->imageResizeUpscale(false)
                    ->maxSize(5120)
                    ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/webp']),
                Forms\Components\Textarea::make('message')
                    ->rows(3),
                Forms\Components\DatePicker::make('born_date')
                    ->label('Birth Date'),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('image')
                    ->disk('public')
                    ->circular(),
                Tables\Columns\TextColumn::make('name'),
                Tables\Columns\TextColumn::make('born_date')
                    ->date(),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()
                    ->visible(fn () => !$this->getOwnerRecord()->isArchived()),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->visible(fn () => !$this->getOwnerRecord()->isArchived()),
                Tables\Actions\DeleteAction::make()
                    ->visible(fn () => !$this->getOwnerRecord()->isArchived()),
            ])
            ->bulkActions([]);
    }
}
