<?php

namespace App\Filament\Resources\PeriodResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;

class StructureHeroesRelationManager extends RelationManager
{
    protected static string $relationship = 'structureHeroes';

    protected static ?string $title = 'Structure Heroes';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('title')
                    ->required()
                    ->maxLength(255),
                Forms\Components\FileUpload::make('image')
                    ->image()
                    ->disk('public')
                    ->directory('structure-heroes')
                    ->required()
                    ->imageResizeMode('cover')
                    ->imageResizeTargetWidth(1920)
                    ->imageResizeTargetHeight(1080)
                    ->imageResizeUpscale(false)
                    ->maxSize(5120)
                    ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/webp']),
                Forms\Components\TextInput::make('order')
                    ->numeric()
                    ->default(0),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->reorderable('order')
            ->defaultSort('order')
            ->columns([
                Tables\Columns\ImageColumn::make('image')
                    ->disk('public')
                    ->square(),
                Tables\Columns\TextColumn::make('title'),
                Tables\Columns\TextColumn::make('order')
                    ->sortable(),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()
                    ->visible(fn () => !$this->getOwnerRecord()->isArchived()),
            ])
            ->actions([
                Tables\Actions\EditAction::make()
                    ->visible(fn () => !$this->getOwnerRecord()->isArchived()),
                Tables\Actions\DeleteAction::make()
                    ->visible(fn () => !$this->getOwnerRecord()->isArchived()),
            ])
            ->bulkActions([]);
    }
}
