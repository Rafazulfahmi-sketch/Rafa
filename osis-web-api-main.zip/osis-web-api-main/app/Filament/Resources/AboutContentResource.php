<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AboutContentResource\Pages;
use App\Models\AboutContent;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Validation\Rules\Unique;

class AboutContentResource extends Resource
{
    protected static ?string $model = AboutContent::class;

    protected static ?string $navigationIcon = 'heroicon-o-information-circle';

    protected static ?string $navigationGroup = 'Content';

    protected static ?int $navigationSort = 2;

    protected static ?string $navigationLabel = 'About Page';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('About Content')
                    ->schema([
                        Forms\Components\Select::make('type')
                            ->options([
                                'vismis' => 'Vision & Mission',
                                'sifat' => 'Sifat',
                                'asas' => 'Asas',
                            ])
                            ->required()
                            ->live()
                            ->unique(ignoreRecord: true)
                            ->disabled(fn (?AboutContent $record) => $record !== null),
                        Forms\Components\FileUpload::make('image')
                            ->image()
                            ->disk('public')
                            ->directory('about')
                            ->imageResizeMode('cover')
                            ->imageResizeTargetWidth(1200)
                            ->imageResizeTargetHeight(800)
                            ->imageResizeUpscale(false)
                            ->maxSize(5120)
                            ->acceptedFileTypes(['image/jpeg', 'image/png', 'image/webp']),
                        Forms\Components\RichEditor::make('vision')
                            ->label('Vision')
                            ->visible(fn (Forms\Get $get) => $get('type') === 'vismis')
                            ->required(fn (Forms\Get $get) => $get('type') === 'vismis')
                            ->columnSpanFull(),
                        Forms\Components\RichEditor::make('mission')
                            ->label('Mission')
                            ->visible(fn (Forms\Get $get) => $get('type') === 'vismis')
                            ->required(fn (Forms\Get $get) => $get('type') === 'vismis')
                            ->columnSpanFull(),
                        Forms\Components\RichEditor::make('content')
                            ->label('Content')
                            ->hidden(fn (Forms\Get $get) => $get('type') === 'vismis')
                            ->required(fn (Forms\Get $get) => $get('type') !== 'vismis')
                            ->columnSpanFull(),
                    ])
                    ->columns(2),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('image')
                    ->disk('public')
                    ->square(),
                Tables\Columns\TextColumn::make('type')
                    ->badge()
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'vismis' => 'Vision & Mission',
                        'sifat' => 'Sifat',
                        'asas' => 'Asas',
                        default => $state,
                    })
                    ->color(fn (string $state): string => match ($state) {
                        'vismis' => 'success',
                        'sifat' => 'warning',
                        'asas' => 'primary',
                        default => 'gray',
                    }),
                Tables\Columns\TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAboutContents::route('/'),
            'create' => Pages\CreateAboutContent::route('/create'),
            'edit' => Pages\EditAboutContent::route('/{record}/edit'),
        ];
    }

    /**
     * Limit creation to 3 records max (one per type).
     */
    public static function canCreate(): bool
    {
        return AboutContent::count() < 3;
    }
}
