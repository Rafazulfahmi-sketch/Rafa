<?php

namespace App\Filament\Widgets;

use App\Models\Achievement;
use App\Models\Department;
use App\Models\Member;
use App\Models\Period;
use App\Models\Program;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class StatsOverview extends BaseWidget
{
    protected static ?int $sort = 1;

    protected function getStats(): array
    {
        $activePeriod = Period::active()->first();
        
        // Count stats for active period
        $departmentCount = $activePeriod 
            ? $activePeriod->departments()->count() 
            : 0;
            
        $memberCount = $activePeriod 
            ? Member::whereHas('department', fn($q) => $q->where('period_id', $activePeriod->id))->count()
            : 0;
            
        $programCount = $activePeriod
            ? Program::whereHas('department', fn($q) => $q->where('period_id', $activePeriod->id))->count()
            : 0;

        return [
            Stat::make('Periode Aktif', $activePeriod?->name ?? 'Tidak ada')
                ->description($activePeriod ? 'Periode kepengurusan saat ini' : 'Belum ada periode aktif')
                ->descriptionIcon($activePeriod ? 'heroicon-m-check-circle' : 'heroicon-m-exclamation-triangle')
                ->color($activePeriod ? 'success' : 'warning'),

            Stat::make('Jumlah Sekbid', $departmentCount)
                ->description('Departemen aktif')
                ->descriptionIcon('heroicon-m-building-office-2')
                ->color('primary'),

            Stat::make('Total Anggota', $memberCount)
                ->description('Anggota periode ini')
                ->descriptionIcon('heroicon-m-users')
                ->color('info'),

            Stat::make('Program Kerja', $programCount)
                ->description('Proker periode ini')
                ->descriptionIcon('heroicon-m-clipboard-document-list')
                ->color('success'),
        ];
    }
}
