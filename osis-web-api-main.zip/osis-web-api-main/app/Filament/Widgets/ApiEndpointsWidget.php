<?php

namespace App\Filament\Widgets;

use Filament\Widgets\Widget;

class ApiEndpointsWidget extends Widget
{
    protected static ?int $sort = 6;

    protected int | string | array $columnSpan = 'full';

    protected static string $view = 'filament.widgets.api-endpoints-widget';

    public function getEndpoints(): array
    {
        $baseUrl = config('app.url') . '/api';

        return [
            [
                'group' => 'Landing Page',
                'endpoints' => [
                    ['method' => 'GET', 'path' => '/landing/heroes', 'description' => 'Hero slides untuk landing page'],
                    ['method' => 'GET', 'path' => '/landing/achievements', 'description' => 'Daftar prestasi'],
                    ['method' => 'GET', 'path' => '/landing/carousels', 'description' => 'Gambar carousel'],
                ],
            ],
            [
                'group' => 'About Page',
                'endpoints' => [
                    ['method' => 'GET', 'path' => '/about/vismis', 'description' => 'Visi & Misi'],
                    ['method' => 'GET', 'path' => '/about/sifat', 'description' => 'Sifat OSIS'],
                    ['method' => 'GET', 'path' => '/about/asas', 'description' => 'Asas OSIS'],
                ],
            ],
            [
                'group' => 'Active Period',
                'endpoints' => [
                    ['method' => 'GET', 'path' => '/period/active/structure', 'description' => 'Struktur organisasi'],
                    ['method' => 'GET', 'path' => '/period/active/advisors', 'description' => 'Daftar pembina'],
                    ['method' => 'GET', 'path' => '/period/active/departments', 'description' => 'Daftar sekbid'],
                ],
            ],
            [
                'group' => 'Department Details',
                'endpoints' => [
                    ['method' => 'GET', 'path' => '/departments/{id}/members', 'description' => 'Anggota sekbid'],
                    ['method' => 'GET', 'path' => '/departments/{id}/programs', 'description' => 'Program kerja sekbid'],
                    ['method' => 'GET', 'path' => '/departments/{id}/achievements', 'description' => 'Prestasi'],
                ],
            ],
        ];
    }

    public function getBaseUrl(): string
    {
        return config('app.url') . '/api';
    }
}
