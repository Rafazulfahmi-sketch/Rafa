<?php

namespace App\Filament\Widgets;

use App\Models\Period;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class ActivePeriodDepartments extends BaseWidget
{
    protected static ?int $sort = 4;

    protected int | string | array $columnSpan = 'full';

    protected static ?string $heading = 'Sekbid Periode Aktif';

    public function table(Table $table): Table
    {
        $activePeriod = Period::active()->first();

        return $table
            ->query(
                $activePeriod 
                    ? $activePeriod->departments()->getQuery()
                    : \App\Models\Department::query()->whereRaw('1 = 0')
            )
            ->columns([
                Tables\Columns\ImageColumn::make('logo')
                    ->disk('public')
                    ->label('Logo')
                    ->circular()
                    ->size(40),
                Tables\Columns\TextColumn::make('name')
                    ->label('Nama Sekbid')
                    ->weight('bold')
                    ->searchable(),
                Tables\Columns\TextColumn::make('members_count')
                    ->label('Anggota')
                    ->counts('members')
                    ->badge()
                    ->color('info'),
                Tables\Columns\TextColumn::make('programs_count')
                    ->label('Proker')
                    ->counts('programs')
                    ->badge()
                    ->color('success'),
                Tables\Columns\TextColumn::make('description')
                    ->label('Deskripsi')
                    ->limit(40)
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->emptyStateHeading('Belum ada sekbid')
            ->emptyStateDescription($activePeriod 
                ? 'Tambahkan sekbid melalui halaman detail periode'
                : 'Aktifkan periode terlebih dahulu')
            ->emptyStateIcon('heroicon-o-building-office-2')
            ->paginated(false)
            ->actions([
                Tables\Actions\Action::make('view')
                    ->label('Lihat')
                    ->icon('heroicon-m-eye')
                    ->url(fn ($record) => route('filament.admin.resources.departments.view', $record)),
            ]);
    }
}
