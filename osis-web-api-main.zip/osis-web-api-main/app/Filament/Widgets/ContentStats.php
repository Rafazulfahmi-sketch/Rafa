<?php

namespace App\Filament\Widgets;

use App\Models\Achievement;
use App\Models\Carousel;
use App\Models\LandingHero;
use App\Models\Period;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class ContentStats extends BaseWidget
{
    protected static ?int $sort = 2;

    protected function getStats(): array
    {
        $totalPeriods = Period::count();
        $archivedPeriods = Period::archived()->count();

        return [
            Stat::make('Prestasi', Achievement::count())
                ->description('Total prestasi civitas')
                ->descriptionIcon('heroicon-m-trophy')
                ->color('warning'),

            Stat::make('Landing Heroes', LandingHero::count())
                ->description('Slide hero landing page')
                ->descriptionIcon('heroicon-m-photo')
                ->color('gray'),

            Stat::make('Carousel', Carousel::count())
                ->description('Gambar carousel')
                ->descriptionIcon('heroicon-m-squares-2x2')
                ->color('gray'),

            Stat::make('Periode Arsip', $archivedPeriods)
                ->description("dari {$totalPeriods} total periode")
                ->descriptionIcon('heroicon-m-archive-box')
                ->color('gray'),
        ];
    }
}
