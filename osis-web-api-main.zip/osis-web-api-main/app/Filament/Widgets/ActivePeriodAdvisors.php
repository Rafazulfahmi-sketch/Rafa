<?php

namespace App\Filament\Widgets;

use App\Models\Period;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class ActivePeriodAdvisors extends BaseWidget
{
    protected static ?int $sort = 3;

    protected int | string | array $columnSpan = 'full';

    protected static ?string $heading = 'Pembina Periode Aktif';

    public function table(Table $table): Table
    {
        $activePeriod = Period::active()->first();

        return $table
            ->query(
                $activePeriod 
                    ? $activePeriod->advisors()->getQuery()
                    : \App\Models\Advisor::query()->whereRaw('1 = 0')
            )
            ->columns([
                Tables\Columns\ImageColumn::make('image')
                    ->disk('public')
                    ->label('Foto')
                    ->circular()
                    ->size(50),
                Tables\Columns\TextColumn::make('name')
                    ->label('Nama')
                    ->weight('bold')
                    ->searchable(),
                Tables\Columns\TextColumn::make('message')
                    ->label('Pesan')
                    ->limit(50)
                    ->wrap(),
                Tables\Columns\TextColumn::make('born_date')
                    ->label('Tanggal Lahir')
                    ->date('d M Y'),
            ])
            ->emptyStateHeading('Belum ada pembina')
            ->emptyStateDescription($activePeriod 
                ? 'Tambahkan pembina melalui halaman detail periode'
                : 'Aktifkan periode terlebih dahulu')
            ->emptyStateIcon('heroicon-o-user-group')
            ->paginated(false);
    }
}
