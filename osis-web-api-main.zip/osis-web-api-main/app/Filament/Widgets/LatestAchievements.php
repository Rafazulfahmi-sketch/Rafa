<?php

namespace App\Filament\Widgets;

use App\Models\Achievement;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;

class LatestAchievements extends BaseWidget
{
    protected static ?int $sort = 5;

    protected int | string | array $columnSpan = 'full';

    protected static ?string $heading = 'Prestasi Terbaru';

    public function table(Table $table): Table
    {
        return $table
            ->query(
                Achievement::query()->latest('date')->limit(5)
            )
            ->columns([
                Tables\Columns\ImageColumn::make('thumbnail')
                    ->disk('public')
                    ->label('Foto')
                    ->square()
                    ->size(50),
                Tables\Columns\TextColumn::make('title')
                    ->label('Judul')
                    ->weight('bold')
                    ->searchable(),
                Tables\Columns\TextColumn::make('participant')
                    ->label('Peserta')
                    ->searchable(),
                Tables\Columns\TextColumn::make('date')
                    ->label('Tanggal')
                    ->date('d M Y')
                    ->sortable(),
            ])
            ->emptyStateHeading('Belum ada prestasi')
            ->emptyStateDescription('Tambahkan prestasi melalui menu Content → Achievements')
            ->emptyStateIcon('heroicon-o-trophy')
            ->paginated(false);
    }
}
